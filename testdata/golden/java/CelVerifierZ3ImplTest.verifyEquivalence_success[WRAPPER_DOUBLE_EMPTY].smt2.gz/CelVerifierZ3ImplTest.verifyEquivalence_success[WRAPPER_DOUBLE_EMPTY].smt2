;; query 1 verifyEquivalence
(push)
(assert (let ((a!1 (ite (fp.isNaN (getDouble (Double (_ +zero 11 53))))                 (_ NaN 11 53)                 (getDouble (Double (_ +zero 11 53)))))) (let ((a!2 (=> (fp.isNaN (getDouble (Double (_ +zero 11 53))))                (= (Double (_ +zero 11 53)) (Double a!1))))) (let ((a!3 (not (and ((_ is Double) (Double (_ +zero 11 53))) a!2))))   (not (= (ite a!3 CelError (Double (_ +zero 11 53))) (Double (_ +zero 11 53))))))))
(assert (let ((a!1 (ite (fp.isNaN (getDouble (Double (_ +zero 11 53))))                 (_ NaN 11 53)                 (getDouble (Double (_ +zero 11 53)))))) (let ((a!2 (=> (fp.isNaN (getDouble (Double (_ +zero 11 53))))                (= (Double (_ +zero 11 53)) (Double a!1))))) (let ((a!3 (not (and ((_ is Double) (Double (_ +zero 11 53))) a!2)))) (let ((a!4 (and ((_ is CelUnknown) (ite a!3 CelError (Double (_ +zero 11 53))))                 ((_ is CelUnknown) (Double (_ +zero 11 53))))))   (not a!4))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (fp.isNaN (getDouble (Double (_ +zero 11 53))))                 (_ NaN 11 53)                 (getDouble (Double (_ +zero 11 53)))))) (let ((a!2 (=> (fp.isNaN (getDouble (Double (_ +zero 11 53))))                (= (Double (_ +zero 11 53)) (Double a!1))))) (let ((a!3 (not (and ((_ is Double) (Double (_ +zero 11 53))) a!2))))   (not (= (ite a!3 CelError (Double (_ +zero 11 53))) (Double (_ +zero 11 53))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
