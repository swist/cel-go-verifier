;; query 1 isAlwaysTrue
(push)
(assert (let ((a!1 (ite (or ((_ is CelError) (Int 1)))                 CelError                 (ite ((_ is Int) (Int 1)) (Int 1) CelError)))) (let ((a!2 (ite (or ((_ is CelUnknown) (Int 1)))                 (CelUnknown !generic_unknown)                 a!1))) (let ((a!3 (Bool (and (>= (getInt a!2) 1) (<= (getInt a!2) 1))))) (let ((a!4 (ite (or ((_ is CelUnknown) a!2))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) a!2)) CelError a!3))))   (not (and ((_ is Bool) a!4) (getBool a!4))))))))
(assert (let ((a!1 (ite (or ((_ is CelError) (Int 1)))                 CelError                 (ite ((_ is Int) (Int 1)) (Int 1) CelError)))       (a!3 (not (ite ((_ is Int) (Int 1)) false false)))) (let ((a!2 (ite (or ((_ is CelUnknown) (Int 1)))                 (CelUnknown !generic_unknown)                 a!1))) (let ((a!4 (or (and ((_ is CelUnknown) a!2) a!3)                (and ((_ is CelError) a!2) a!3 (not ((_ is CelUnknown) a!2)))                a!3)))   (not (not a!4))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (or ((_ is CelError) (Int 1)))                 CelError                 (ite ((_ is Int) (Int 1)) (Int 1) CelError)))) (let ((a!2 (ite (or ((_ is CelUnknown) (Int 1)))                 (CelUnknown !generic_unknown)                 a!1))) (let ((a!3 (Bool (and (>= (getInt a!2) 1) (<= (getInt a!2) 1))))) (let ((a!4 (ite (or ((_ is CelUnknown) a!2))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) a!2)) CelError a!3))))   (not (and ((_ is Bool) a!4) (getBool a!4))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
