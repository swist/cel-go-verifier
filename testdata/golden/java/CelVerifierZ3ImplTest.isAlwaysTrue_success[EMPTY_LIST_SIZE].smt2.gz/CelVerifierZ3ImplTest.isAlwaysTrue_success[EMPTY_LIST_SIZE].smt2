;; query 1 isAlwaysTrue
(assert (= (as_seq !listRef_!0) (as seq.empty (Seq CelValue))))
(assert (let ((a!1 (seq.len (as_seq (getListRef (List !listRef_!0))))))   (<= a!1 2147483647)))
(assert (= (!mkListRef (as_seq !listRef_!0)) !listRef_!0))
(assert (let ((a!1 (!mkListRef (as_seq (getListRef (List !listRef_!0))))))   (=> ((_ is List) (List !listRef_!0)) (= a!1 (getListRef (List !listRef_!0))))))
(push)
(assert (let ((a!1 (seq.len (as_seq (getListRef (List !listRef_!0)))))       (a!2 (ite (or ((_ is CelUnknown) (List !listRef_!0)))                 (CelUnknown !generic_unknown)                 CelError))) (let ((a!3 (ite (or ((_ is CelError) (List !listRef_!0)))                 CelError                 (ite ((_ is List) (List !listRef_!0)) (Int a!1) a!2)))) (let ((a!4 (ite (or ((_ is CelUnknown) (List !listRef_!0)))                 (CelUnknown !generic_unknown)                 a!3))) (let ((a!5 (Bool (and (>= (getInt a!4) 0) (<= (getInt a!4) 0))))) (let ((a!6 (ite (or ((_ is CelUnknown) a!4))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) a!4)) CelError a!5))))   (not (and ((_ is Bool) a!6) (getBool a!6)))))))))
(assert (let ((a!1 (seq.len (as_seq (getListRef (List !listRef_!0)))))       (a!2 (ite (or ((_ is CelUnknown) (List !listRef_!0)))                 (CelUnknown !generic_unknown)                 CelError))       (a!5 (not (ite ((_ is List) (List !listRef_!0)) false false)))) (let ((a!3 (ite (or ((_ is CelError) (List !listRef_!0)))                 CelError                 (ite ((_ is List) (List !listRef_!0)) (Int a!1) a!2)))) (let ((a!4 (ite (or ((_ is CelUnknown) (List !listRef_!0)))                 (CelUnknown !generic_unknown)                 a!3))) (let ((a!6 (or (and ((_ is CelUnknown) a!4) a!5)                (and ((_ is CelError) a!4) a!5 (not ((_ is CelUnknown) a!4)))                a!5)))   (not (not a!6)))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (seq.len (as_seq (getListRef (List !listRef_!0)))))       (a!2 (ite (or ((_ is CelUnknown) (List !listRef_!0)))                 (CelUnknown !generic_unknown)                 CelError))) (let ((a!3 (ite (or ((_ is CelError) (List !listRef_!0)))                 CelError                 (ite ((_ is List) (List !listRef_!0)) (Int a!1) a!2)))) (let ((a!4 (ite (or ((_ is CelUnknown) (List !listRef_!0)))                 (CelUnknown !generic_unknown)                 a!3))) (let ((a!5 (Bool (and (>= (getInt a!4) 0) (<= (getInt a!4) 0))))) (let ((a!6 (ite (or ((_ is CelUnknown) a!4))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) a!4)) CelError a!5))))   (not (and ((_ is Bool) a!6) (getBool a!6)))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
