;; query 1 verifyEquivalence
(push)
(assert (let ((a!1 (String (str.++ (getString (String "abc"))                            (getString (String "def")))))) (let ((a!2 (ite (and ((_ is String) (String "abc"))                      ((_ is String) (String "def")))                 a!1                 CelError))) (let ((a!3 (ite (or ((_ is CelError) (String "abc"))                     ((_ is CelError) (String "def")))                 CelError                 a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) (String "abc"))                     ((_ is CelUnknown) (String "def")))                 (CelUnknown (_+_ (String "abc") (String "def")))                 a!3)))   (not (= a!4 (String "abcdef"))))))))
(assert (let ((a!1 (ite (and ((_ is String) (String "abc"))                      ((_ is String) (String "def")))                 false                 false))       (a!2 (String (str.++ (getString (String "abc"))                            (getString (String "def")))))) (let ((a!3 (ite (and ((_ is String) (String "abc"))                      ((_ is String) (String "def")))                 a!2                 CelError))) (let ((a!4 (ite (or ((_ is CelError) (String "abc"))                     ((_ is CelError) (String "def")))                 CelError                 a!3))) (let ((a!5 (ite (or ((_ is CelUnknown) (String "abc"))                     ((_ is CelUnknown) (String "def")))                 (CelUnknown (_+_ (String "abc") (String "def")))                 a!4))) (let ((a!6 (or a!1                (and ((_ is CelUnknown) a!5)                     ((_ is CelUnknown) (String "abcdef"))))))   (not a!6)))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (String (str.++ (getString (String "abc"))                            (getString (String "def")))))) (let ((a!2 (ite (and ((_ is String) (String "abc"))                      ((_ is String) (String "def")))                 a!1                 CelError))) (let ((a!3 (ite (or ((_ is CelError) (String "abc"))                     ((_ is CelError) (String "def")))                 CelError                 a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) (String "abc"))                     ((_ is CelUnknown) (String "def")))                 (CelUnknown (_+_ (String "abc") (String "def")))                 a!3)))   (not (= a!4 (String "abcdef"))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
