;; query 1 isAlwaysTrue
(assert (not ((_ is CelError) x)))
(assert (let ((a!1 (not (or (> (getInt x) 9223372036854775807)                     (< (getInt x) (- 9223372036854775808))))))   (or ((_ is CelUnknown) x)       ((_ is CelError) x)       ((_ is CelUnknown) x)       (and ((_ is Int) x) a!1))))
(push)
(assert (let ((a!1 (ite (or ((_ is CelError) x) ((_ is CelError) x))                 CelError                 (Bool (= (getInt x) (getInt x)))))) (let ((a!2 ((_ is Bool)              (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) x))                   (CelUnknown !generic_unknown)                   a!1)))       (a!3 (getBool (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) x))                          (CelUnknown !generic_unknown)                          a!1))))   (not (and a!2 a!3)))))
(assert (not false))
(check-sat) ; SATISFIABLE
