;; query 1 verifyEquivalence
(push)
(assert (let ((a!1 (or (not ((_ is Int) (Int (- 1))))                (not ((_ is Int) (Int 0)))                (< (getInt (Int 0)) 0)                (>= (getInt (Int 0)) 1000000000)))       (a!2 (+ (* (getInt (Int (- 1))) 1000000000) (getInt (Int 0))))) (let ((a!3 (ite a!1                 CelError                 (ite (or (> a!2 253402300799999999999)                          (< a!2 (- 62135596800000000000)))                      CelError                      (Timestamp a!2))))) (let ((a!4 (ite ((_ is Timestamp) a!3)                 (Int (div (getTimestamp a!3) 1000000000))                 (ite (or ((_ is CelUnknown) a!3))                      (CelUnknown (int a!3))                      CelError)))) (let ((a!5 (ite (or ((_ is CelUnknown) a!3))                 (CelUnknown (int a!3))                 (ite (or ((_ is CelError) a!3)) CelError a!4))))   (not (= a!5 (Int (- 1)))))))))
(assert (let ((a!1 (or (not ((_ is Int) (Int (- 1))))                (not ((_ is Int) (Int 0)))                (< (getInt (Int 0)) 0)                (>= (getInt (Int 0)) 1000000000)))       (a!2 (+ (* (getInt (Int (- 1))) 1000000000) (getInt (Int 0))))) (let ((a!3 (ite a!1                 CelError                 (ite (or (> a!2 253402300799999999999)                          (< a!2 (- 62135596800000000000)))                      CelError                      (Timestamp a!2))))) (let ((a!4 (ite ((_ is Timestamp) a!3)                 (Int (div (getTimestamp a!3) 1000000000))                 (ite (or ((_ is CelUnknown) a!3))                      (CelUnknown (int a!3))                      CelError)))) (let ((a!5 (ite (or ((_ is CelUnknown) a!3))                 (CelUnknown (int a!3))                 (ite (or ((_ is CelError) a!3)) CelError a!4)))) (let ((a!6 (or (ite ((_ is Timestamp) a!3) false false)                (and ((_ is CelUnknown) a!5) ((_ is CelUnknown) (Int (- 1)))))))   (not a!6)))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (or (not ((_ is Int) (Int (- 1))))                (not ((_ is Int) (Int 0)))                (< (getInt (Int 0)) 0)                (>= (getInt (Int 0)) 1000000000)))       (a!2 (+ (* (getInt (Int (- 1))) 1000000000) (getInt (Int 0))))) (let ((a!3 (ite a!1                 CelError                 (ite (or (> a!2 253402300799999999999)                          (< a!2 (- 62135596800000000000)))                      CelError                      (Timestamp a!2))))) (let ((a!4 (ite ((_ is Timestamp) a!3)                 (Int (div (getTimestamp a!3) 1000000000))                 (ite (or ((_ is CelUnknown) a!3))                      (CelUnknown (int a!3))                      CelError)))) (let ((a!5 (ite (or ((_ is CelUnknown) a!3))                 (CelUnknown (int a!3))                 (ite (or ((_ is CelError) a!3)) CelError a!4))))   (not (= a!5 (Int (- 1)))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
