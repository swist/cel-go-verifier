;; query 1 verifyEquivalence
(assert (not ((_ is CelError) a)))
(assert (not ((_ is CelUnknown) a)))
(assert (or ((_ is CelError) a) ((_ is CelUnknown) a) ((_ is Bool) a)))
(assert (not ((_ is CelError) b)))
(assert (not ((_ is CelUnknown) b)))
(assert (or ((_ is CelError) b) ((_ is CelUnknown) b) ((_ is Bool) b)))
(push)
(assert (let ((a!1 (ite (or ((_ is CelError) a)) CelError (Bool (not (getBool a)))))       (a!4 (ite (or ((_ is CelError) b)) CelError (Bool (not (getBool b)))))) (let ((a!2 ((_ is Bool)              (ite (or ((_ is CelUnknown) a)) (CelUnknown (!_ a)) a!1)))       (a!3 (getBool (ite (or ((_ is CelUnknown) a)) (CelUnknown (!_ a)) a!1)))       (a!5 ((_ is Bool)              (ite (or ((_ is CelUnknown) b)) (CelUnknown (!_ b)) a!4)))       (a!6 (getBool (ite (or ((_ is CelUnknown) b)) (CelUnknown (!_ b)) a!4)))       (a!7 ((_ is CelUnknown)              (ite (or ((_ is CelUnknown) a)) (CelUnknown (!_ a)) a!1)))       (a!8 ((_ is CelUnknown)              (ite (or ((_ is CelUnknown) b)) (CelUnknown (!_ b)) a!4)))       (a!9 (|_\|\|_| (ite (or ((_ is CelUnknown) a)) (CelUnknown (!_ a)) a!1)                      (ite (or ((_ is CelUnknown) b)) (CelUnknown (!_ b)) a!4)))) (let ((a!10 (ite (or (not (or a!2 a!7)) (not (or a!5 a!8)))                  CelError                  (Bool false)))) (let ((a!11 (ite (or (and a!2 a!3) (and a!5 a!6))                  (Bool true)                  (ite (or a!7 a!8) (CelUnknown a!9) a!10))))   (not (= a!11 a!11)))))))
(assert (let ((a!1 (ite (or ((_ is CelError) a)) CelError (Bool (not (getBool a)))))       (a!4 (ite (or ((_ is CelError) b)) CelError (Bool (not (getBool b)))))) (let ((a!2 ((_ is Bool)              (ite (or ((_ is CelUnknown) a)) (CelUnknown (!_ a)) a!1)))       (a!3 (getBool (ite (or ((_ is CelUnknown) a)) (CelUnknown (!_ a)) a!1)))       (a!5 ((_ is Bool)              (ite (or ((_ is CelUnknown) b)) (CelUnknown (!_ b)) a!4)))       (a!6 (getBool (ite (or ((_ is CelUnknown) b)) (CelUnknown (!_ b)) a!4)))       (a!7 ((_ is CelUnknown)              (ite (or ((_ is CelUnknown) a)) (CelUnknown (!_ a)) a!1)))       (a!8 ((_ is CelUnknown)              (ite (or ((_ is CelUnknown) b)) (CelUnknown (!_ b)) a!4)))       (a!9 (|_\|\|_| (ite (or ((_ is CelUnknown) a)) (CelUnknown (!_ a)) a!1)                      (ite (or ((_ is CelUnknown) b)) (CelUnknown (!_ b)) a!4)))) (let ((a!10 (ite (or (not (or a!2 a!7)) (not (or a!5 a!8)))                  CelError                  (Bool false)))) (let ((a!11 ((_ is CelUnknown)               (ite (or (and a!2 a!3) (and a!5 a!6))                    (Bool true)                    (ite (or a!7 a!8) (CelUnknown a!9) a!10)))))   (not (and a!11 a!11)))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (or ((_ is CelError) a)) CelError (Bool (not (getBool a)))))       (a!4 (ite (or ((_ is CelError) b)) CelError (Bool (not (getBool b)))))) (let ((a!2 ((_ is Bool)              (ite (or ((_ is CelUnknown) a)) (CelUnknown (!_ a)) a!1)))       (a!3 (getBool (ite (or ((_ is CelUnknown) a)) (CelUnknown (!_ a)) a!1)))       (a!5 ((_ is Bool)              (ite (or ((_ is CelUnknown) b)) (CelUnknown (!_ b)) a!4)))       (a!6 (getBool (ite (or ((_ is CelUnknown) b)) (CelUnknown (!_ b)) a!4)))       (a!7 ((_ is CelUnknown)              (ite (or ((_ is CelUnknown) a)) (CelUnknown (!_ a)) a!1)))       (a!8 ((_ is CelUnknown)              (ite (or ((_ is CelUnknown) b)) (CelUnknown (!_ b)) a!4)))       (a!9 (|_\|\|_| (ite (or ((_ is CelUnknown) a)) (CelUnknown (!_ a)) a!1)                      (ite (or ((_ is CelUnknown) b)) (CelUnknown (!_ b)) a!4)))) (let ((a!10 (ite (or (not (or a!2 a!7)) (not (or a!5 a!8)))                  CelError                  (Bool false)))) (let ((a!11 (ite (or (and a!2 a!3) (and a!5 a!6))                  (Bool true)                  (ite (or a!7 a!8) (CelUnknown a!9) a!10))))   (not (= a!11 a!11)))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
