;; query 1 verifyEquivalence
(assert (not ((_ is CelError) d)))
(assert (not ((_ is CelUnknown) d)))
(assert (let ((a!1 (Double (ite (fp.isNaN (getDouble d)) (_ NaN 11 53) (getDouble d))))) (let ((a!2 (and ((_ is Double) d) (=> (fp.isNaN (getDouble d)) (= d a!1)))))   (or ((_ is CelError) d) ((_ is CelUnknown) d) a!2))))
(push)
(assert (let ((a!1 (ite (or ((_ is CelError) d))                 CelError                 (Bool (fp.eq (getDouble d) (_ +oo 11 53)))))       (a!3 (ite (or ((_ is CelError) d))                 CelError                 (Bool (fp.eq (getDouble d) (_ -oo 11 53)))))) (let ((a!2 (ite (or ((_ is CelUnknown) d))                 (CelUnknown (_==_ d (Double (_ +oo 11 53))))                 a!1))       (a!4 (ite (or ((_ is CelUnknown) d))                 (CelUnknown (_==_ d (Double (_ -oo 11 53))))                 a!3)))   (not (= a!2 a!4)))))
(assert (let ((a!1 (ite (or ((_ is CelError) d))                 CelError                 (Bool (fp.eq (getDouble d) (_ +oo 11 53)))))       (a!3 (ite (or ((_ is CelError) d))                 CelError                 (Bool (fp.eq (getDouble d) (_ -oo 11 53)))))) (let ((a!2 (ite (or ((_ is CelUnknown) d))                 (CelUnknown (_==_ d (Double (_ +oo 11 53))))                 a!1))       (a!4 (ite (or ((_ is CelUnknown) d))                 (CelUnknown (_==_ d (Double (_ -oo 11 53))))                 a!3)))   (not (and ((_ is CelUnknown) a!2) ((_ is CelUnknown) a!4))))))
(check-sat) ; SATISFIABLE
