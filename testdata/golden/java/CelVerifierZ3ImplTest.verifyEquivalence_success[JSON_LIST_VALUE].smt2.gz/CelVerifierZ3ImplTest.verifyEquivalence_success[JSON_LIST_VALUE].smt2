;; query 1 verifyEquivalence
(assert (= (as_seq !empty_list!0) (as seq.empty (Seq CelValue))))
(assert (= (as_seq !listRef_!1)    (seq.++ (as seq.empty (Seq CelValue)) (seq.unit (Int 1)) (seq.unit (Int 2)))))
(assert (=> (!has_truncated_type_constraint (Int 1))     (or ((_ is CelError) (List !listRef_!1))         ((_ is CelUnknown) (List !listRef_!1))         (!has_truncated_type_constraint (List !listRef_!1)))))
(assert (=> (!has_truncated_type_constraint (Int 2))     (or ((_ is CelError) (List !listRef_!1))         ((_ is CelUnknown) (List !listRef_!1))         (!has_truncated_type_constraint (List !listRef_!1)))))
(assert (= (!mkListRef (as_seq !empty_list!0)) !empty_list!0))
(assert (= (!mkListRef (as_seq !listRef_!1)) !listRef_!1))
(push)
(assert (let ((a!1 (ite (or ((_ is CelError) (List !listRef_!1)))                 CelError                 (List !listRef_!1)))) (let ((a!2 (ite (or ((_ is CelUnknown) (List !listRef_!1)))                 (CelUnknown (|struct_google.protobuf.ListValue_values:false|                               (List !listRef_!1)))                 a!1)))   (not (= a!2 (List !listRef_!1))))))
(assert (let ((a!1 (ite (or ((_ is CelError) (List !listRef_!1)))                 CelError                 (List !listRef_!1)))) (let ((a!2 (ite (or ((_ is CelUnknown) (List !listRef_!1)))                 (CelUnknown (|struct_google.protobuf.ListValue_values:false|                               (List !listRef_!1)))                 a!1)))   (not (and ((_ is CelUnknown) a!2) ((_ is CelUnknown) (List !listRef_!1)))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (or ((_ is CelError) (List !listRef_!1)))                 CelError                 (List !listRef_!1)))) (let ((a!2 (ite (or ((_ is CelUnknown) (List !listRef_!1)))                 (CelUnknown (|struct_google.protobuf.ListValue_values:false|                               (List !listRef_!1)))                 a!1)))   (not (= a!2 (List !listRef_!1))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
