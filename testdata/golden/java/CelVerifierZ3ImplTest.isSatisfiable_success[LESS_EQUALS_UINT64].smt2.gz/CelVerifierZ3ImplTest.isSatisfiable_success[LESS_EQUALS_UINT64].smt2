;; query 1 isSatisfiable
(assert (not ((_ is CelError) u)))
(assert (not ((_ is CelUnknown) u)))
(assert (let ((a!1 (not (or (> (getUint u) 18446744073709551615) (< (getUint u) 0)))))   (or ((_ is CelError) u) ((_ is CelUnknown) u) (and ((_ is Uint) u) a!1))))
(push)
(assert (let ((a!1 (Bool (<= (getUint u) (getUint (Uint 5)))))) (let ((a!2 (ite (and ((_ is Uint) u) ((_ is Uint) (Uint 5)))                 a!1                 (ite (or ((_ is CelUnknown) u))                      (CelUnknown !generic_unknown)                      CelError)))) (let ((a!3 (ite (or ((_ is CelError) u) ((_ is CelError) (Uint 5)))                 CelError                 a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) u) ((_ is CelUnknown) (Uint 5)))                 (CelUnknown !generic_unknown)                 a!3)))   (and ((_ is Bool) a!4) (getBool a!4)))))))
(assert (let ((a!1 (ite (and ((_ is Uint) u) ((_ is Uint) (Uint 5))) false false)))   (not a!1)))
(check-sat) ; SATISFIABLE
