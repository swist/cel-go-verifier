;; query 1 verifyEquivalence
(assert (let ((a!1 (seq.++ (as seq.empty (Seq CelValue))                    (seq.unit (ite true (Optional !optionalNoneRef) CelError)))))   (= (as_seq !listRef_!0) a!1)))
(assert (=> (!has_truncated_type_constraint       (ite true (Optional !optionalNoneRef) CelError))     (or ((_ is CelError) (List !listRef_!0))         ((_ is CelUnknown) (List !listRef_!0))         (!has_truncated_type_constraint (List !listRef_!0)))))
(assert (= (!mkListRef (as_seq !listRef_!0)) !listRef_!0))
(push)
(assert (let ((a!1 (or ((_ is CelUnknown)                  (ite true (Optional !optionalNoneRef) CelError))))       (a!2 (CelUnknown (|LIST_[]| (ite true                                        (Optional !optionalNoneRef)                                        CelError))))       (a!3 (or ((_ is CelError) (ite true (Optional !optionalNoneRef) CelError))))) (let ((a!4 (= (ite a!1 a!2 (ite a!3 CelError (List !listRef_!0)))               (ite a!1 a!2 (ite a!3 CelError (List !listRef_!0))))))   (not a!4))))
(assert (let ((a!1 (and ((_ is CelUnknown)                   (ite true (Optional !optionalNoneRef) CelError))                 (not (ite true false false))))       (a!2 (not ((_ is CelUnknown)                   (ite true (Optional !optionalNoneRef) CelError))))       (a!5 (or ((_ is CelUnknown)                  (ite true (Optional !optionalNoneRef) CelError))))       (a!6 (CelUnknown (|LIST_[]| (ite true                                        (Optional !optionalNoneRef)                                        CelError))))       (a!7 (or ((_ is CelError) (ite true (Optional !optionalNoneRef) CelError))))) (let ((a!3 (and ((_ is CelError)                   (ite true (Optional !optionalNoneRef) CelError))                 (not (ite true false false))                 a!2))       (a!8 ((_ is CelUnknown)              (ite a!5 a!6 (ite a!7 CelError (List !listRef_!0)))))) (let ((a!4 (not (or a!1 a!3 (not (ite true false false))))))   (not (or a!4 a!4 (and a!8 a!8)))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (or ((_ is CelUnknown)                  (ite true (Optional !optionalNoneRef) CelError))))       (a!2 (CelUnknown (|LIST_[]| (ite true                                        (Optional !optionalNoneRef)                                        CelError))))       (a!3 (or ((_ is CelError) (ite true (Optional !optionalNoneRef) CelError))))) (let ((a!4 (= (ite a!1 a!2 (ite a!3 CelError (List !listRef_!0)))               (ite a!1 a!2 (ite a!3 CelError (List !listRef_!0))))))   (not a!4))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
