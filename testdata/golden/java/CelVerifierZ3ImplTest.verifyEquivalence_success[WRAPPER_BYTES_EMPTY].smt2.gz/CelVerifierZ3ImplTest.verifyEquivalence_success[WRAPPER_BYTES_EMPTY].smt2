;; query 1 verifyEquivalence
(push)
(assert (let ((a!1 (ite (not ((_ is Bytes) (Bytes ""))) CelError (Bytes ""))))   (not (= a!1 (Bytes "")))))
(assert (let ((a!1 (ite (not ((_ is Bytes) (Bytes ""))) CelError (Bytes ""))))   (not (and ((_ is CelUnknown) a!1) ((_ is CelUnknown) (Bytes ""))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (not ((_ is Bytes) (Bytes ""))) CelError (Bytes ""))))   (not (= a!1 (Bytes "")))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
