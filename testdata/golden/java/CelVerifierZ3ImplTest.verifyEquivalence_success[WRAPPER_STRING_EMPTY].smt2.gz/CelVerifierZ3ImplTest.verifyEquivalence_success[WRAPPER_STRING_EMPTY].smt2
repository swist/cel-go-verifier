;; query 1 verifyEquivalence
(push)
(assert (let ((a!1 (ite (not ((_ is String) (String ""))) CelError (String ""))))   (not (= a!1 (String "")))))
(assert (let ((a!1 (ite (not ((_ is String) (String ""))) CelError (String ""))))   (not (and ((_ is CelUnknown) a!1) ((_ is CelUnknown) (String ""))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (not ((_ is String) (String ""))) CelError (String ""))))   (not (= a!1 (String "")))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
