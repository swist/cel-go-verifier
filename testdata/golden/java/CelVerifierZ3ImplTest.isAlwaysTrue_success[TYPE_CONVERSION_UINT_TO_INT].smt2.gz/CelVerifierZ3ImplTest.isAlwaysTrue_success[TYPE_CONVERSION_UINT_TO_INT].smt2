;; query 1 isAlwaysTrue
(push)
(assert (let ((a!1 (ite (> (getUint (Uint 1)) 9223372036854775807)                 CelError                 (Int (getUint (Uint 1)))))) (let ((a!2 (ite (or ((_ is CelError) (Uint 1)))                 CelError                 (ite ((_ is Uint) (Uint 1)) a!1 CelError)))) (let ((a!3 (ite (or ((_ is CelUnknown) (Uint 1)))                 (CelUnknown !generic_unknown)                 a!2))) (let ((a!4 (Bool (and (>= (getInt a!3) 1) (<= (getInt a!3) 1))))) (let ((a!5 (ite (or ((_ is CelUnknown) a!3))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) a!3)) CelError a!4))))   (not (and ((_ is Bool) a!5) (getBool a!5)))))))))
(assert (let ((a!1 (ite (> (getUint (Uint 1)) 9223372036854775807)                 CelError                 (Int (getUint (Uint 1)))))       (a!4 (not (ite ((_ is Uint) (Uint 1)) false false)))) (let ((a!2 (ite (or ((_ is CelError) (Uint 1)))                 CelError                 (ite ((_ is Uint) (Uint 1)) a!1 CelError)))) (let ((a!3 (ite (or ((_ is CelUnknown) (Uint 1)))                 (CelUnknown !generic_unknown)                 a!2))) (let ((a!5 (or (and ((_ is CelUnknown) a!3) a!4)                (and ((_ is CelError) a!3) a!4 (not ((_ is CelUnknown) a!3)))                a!4)))   (not (not a!5)))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (> (getUint (Uint 1)) 9223372036854775807)                 CelError                 (Int (getUint (Uint 1)))))) (let ((a!2 (ite (or ((_ is CelError) (Uint 1)))                 CelError                 (ite ((_ is Uint) (Uint 1)) a!1 CelError)))) (let ((a!3 (ite (or ((_ is CelUnknown) (Uint 1)))                 (CelUnknown !generic_unknown)                 a!2))) (let ((a!4 (Bool (and (>= (getInt a!3) 1) (<= (getInt a!3) 1))))) (let ((a!5 (ite (or ((_ is CelUnknown) a!3))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) a!3)) CelError a!4))))   (not (and ((_ is Bool) a!5) (getBool a!5)))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
