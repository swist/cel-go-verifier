;; query 1 isAlwaysTrue
(push)
(assert (not (and ((_ is Bool) (Bool true)) (getBool (Bool true)))))
(assert (not false))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (not (and ((_ is Bool) (Bool true)) (getBool (Bool true)))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
