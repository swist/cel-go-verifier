;; query 1 isAlwaysTrue
(assert (<= (str.len (getBytes (Bytes "abc"))) 2147483647))
(push)
(assert (let ((a!1 (Int (str.len (getBytes (Bytes "abc")))))) (let ((a!2 (ite (or ((_ is CelError) (Bytes "abc")))                 CelError                 (ite ((_ is Bytes) (Bytes "abc")) a!1 CelError)))) (let ((a!3 (ite (or ((_ is CelUnknown) (Bytes "abc")))                 (CelUnknown !generic_unknown)                 a!2))) (let ((a!4 (Bool (and (>= (getInt a!3) 3) (<= (getInt a!3) 3))))) (let ((a!5 (ite (or ((_ is CelUnknown) a!3))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) a!3)) CelError a!4))))   (not (and ((_ is Bool) a!5) (getBool a!5)))))))))
(assert (let ((a!1 (Int (str.len (getBytes (Bytes "abc")))))       (a!4 (not (ite ((_ is Bytes) (Bytes "abc")) false false)))) (let ((a!2 (ite (or ((_ is CelError) (Bytes "abc")))                 CelError                 (ite ((_ is Bytes) (Bytes "abc")) a!1 CelError)))) (let ((a!3 (ite (or ((_ is CelUnknown) (Bytes "abc")))                 (CelUnknown !generic_unknown)                 a!2))) (let ((a!5 (or (and ((_ is CelUnknown) a!3) a!4)                (and ((_ is CelError) a!3) a!4 (not ((_ is CelUnknown) a!3)))                a!4)))   (not (not a!5)))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (Int (str.len (getBytes (Bytes "abc")))))) (let ((a!2 (ite (or ((_ is CelError) (Bytes "abc")))                 CelError                 (ite ((_ is Bytes) (Bytes "abc")) a!1 CelError)))) (let ((a!3 (ite (or ((_ is CelUnknown) (Bytes "abc")))                 (CelUnknown !generic_unknown)                 a!2))) (let ((a!4 (Bool (and (>= (getInt a!3) 3) (<= (getInt a!3) 3))))) (let ((a!5 (ite (or ((_ is CelUnknown) a!3))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) a!3)) CelError a!4))))   (not (and ((_ is Bool) a!5) (getBool a!5)))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
