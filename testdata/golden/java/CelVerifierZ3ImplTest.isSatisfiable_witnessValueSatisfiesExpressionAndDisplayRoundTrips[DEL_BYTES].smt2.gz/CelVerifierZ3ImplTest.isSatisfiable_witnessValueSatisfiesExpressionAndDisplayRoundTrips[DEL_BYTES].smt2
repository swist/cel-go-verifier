;; query 1 isSatisfiable
(assert (not ((_ is CelError) by)))
(assert (not ((_ is CelUnknown) by)))
(assert (or ((_ is CelError) by) ((_ is CelUnknown) by) ((_ is Bytes) by)))
(assert (let ((a!1 (= (!mkListRef (as_seq (getListRef by))) (getListRef by))))   (=> ((_ is List) by) a!1)))
(assert (let ((a!1 (!mkListRef (as_seq (getListRef (Bytes ""))))))   (=> ((_ is List) (Bytes "")) (= a!1 (getListRef (Bytes ""))))))
(assert (let ((a!1 (= (!mkMapRef (map_values (getMapRef by))                          (map_presence (getMapRef by)))               (getMapRef by))))   (=> ((_ is Map) by) a!1)))
(assert (let ((a!1 (!mkMapRef (map_values (getMapRef (Bytes "")))                       (map_presence (getMapRef (Bytes ""))))))   (=> ((_ is Map) (Bytes "")) (= a!1 (getMapRef (Bytes ""))))))
(assert (let ((a!1 (= (!mkMsgRef (msg_type_name (getMessageRef by))                          (msg_values (getMessageRef by))                          (msg_presence (getMessageRef by)))               (getMessageRef by))))   (=> ((_ is Message) by) a!1)))
(assert (let ((a!1 (!mkMsgRef (msg_type_name (getMessageRef (Bytes "")))                       (msg_values (getMessageRef (Bytes "")))                       (msg_presence (getMessageRef (Bytes ""))))))   (=> ((_ is Message) (Bytes "")) (= a!1 (getMessageRef (Bytes ""))))))
(push)
(assert (let ((a!1 (= (as_seq (getListRef by)) (as_seq (getListRef (Bytes "")))))       (a!2 (= (map_presence (getMapRef by))               (map_presence (getMapRef (Bytes "")))))       (a!3 (= (map_values (getMapRef by)) (map_values (getMapRef (Bytes "")))))       (a!4 (= (msg_type_name (getMessageRef by))               (msg_type_name (getMessageRef (Bytes "")))))       (a!5 (= (msg_values (getMessageRef by))               (msg_values (getMessageRef (Bytes "")))))       (a!6 (= (msg_presence (getMessageRef by))               (msg_presence (getMessageRef (Bytes "")))))       (a!7 (ite (and ((_ is Double) by) ((_ is Double) (Bytes "")))                 (fp.eq (getDouble by) (getDouble (Bytes "")))                 (= by (Bytes ""))))) (let ((a!8 (ite (and ((_ is Message) by) ((_ is Message) (Bytes "")))                 (and a!4 a!5 a!6)                 a!7))) (let ((a!9 (ite (and ((_ is Map) by) ((_ is Map) (Bytes "")))                 (and a!2 a!3)                 a!8))) (let ((a!10 (ite (and ((_ is List) by) ((_ is List) (Bytes ""))) a!1 a!9))) (let ((a!11 (ite (or ((_ is CelUnknown) by))                  (CelUnknown !generic_unknown)                  (ite (or ((_ is CelError) by)) CelError (Bool a!10)))))   (and ((_ is Bool) a!11) (getBool a!11))))))))
(assert (not false))
(check-sat) ; SATISFIABLE
