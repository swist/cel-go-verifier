;; query 1 isAlwaysTrue
(push)
(assert (let ((a!1 (Bool (fp.eq (getDouble (Double (_ +zero 11 53))) (_ -zero 11 53)))))   (not (and ((_ is Bool) a!1) (getBool a!1)))))
(assert (not false))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (Bool (fp.eq (getDouble (Double (_ +zero 11 53))) (_ -zero 11 53)))))   (not (and ((_ is Bool) a!1) (getBool a!1)))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
