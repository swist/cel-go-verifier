;; query 1 verifyEquivalence
(assert (not ((_ is CelError) unknown_var)))
(assert (not ((_ is CelUnknown) unknown_var)))
(assert (let ((a!1 (not (or (> (getInt unknown_var) 9223372036854775807)                     (< (getInt unknown_var) (- 9223372036854775808)))))       (a!2 (not (or (> (getUint unknown_var) 18446744073709551615)                     (< (getUint unknown_var) 0))))       (a!3 (Double (ite (fp.isNaN (getDouble unknown_var))                         (_ NaN 11 53)                         (getDouble unknown_var))))       (a!5 (not (or (> (getTimestamp unknown_var) 253402300799999999999)                     (< (getTimestamp unknown_var) (- 62135596800000000000)))))       (a!6 (not (or (> (getDuration unknown_var) 315576000000999999999)                     (< (getDuration unknown_var) (- 315576000000999999999)))))) (let ((a!4 (=> (and ((_ is Double) unknown_var)                     (fp.isNaN (getDouble unknown_var)))                (= unknown_var a!3))))   (or ((_ is CelError) unknown_var)       ((_ is CelUnknown) unknown_var)       (and (=> ((_ is Int) unknown_var) a!1)            (=> ((_ is Uint) unknown_var) a!2)            a!4            (=> ((_ is Timestamp) unknown_var) a!5)            (=> ((_ is Duration) unknown_var) a!6))))))
(push)
(assert (let ((a!1 (or (and ((_ is Bool) unknown_var) (getBool unknown_var))                (and ((_ is Bool) (Bool true)) (getBool (Bool true)))))       (a!2 (not (or ((_ is Bool) (Bool true)) ((_ is CelUnknown) (Bool true)))))) (let ((a!3 (or (not (or ((_ is Bool) unknown_var)                         ((_ is CelUnknown) unknown_var)))                a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) unknown_var)                     ((_ is CelUnknown) (Bool true)))                 (CelUnknown (|_\|\|_| unknown_var (Bool true)))                 (ite a!3 CelError (Bool false)))))   (not (= (ite a!1 (Bool true) a!4) (Bool true)))))))
(assert (let ((a!1 (or (and ((_ is Bool) unknown_var) (getBool unknown_var))                (and ((_ is Bool) (Bool true)) (getBool (Bool true)))))       (a!2 (not (or ((_ is Bool) (Bool true)) ((_ is CelUnknown) (Bool true)))))) (let ((a!3 (or (not (or ((_ is Bool) unknown_var)                         ((_ is CelUnknown) unknown_var)))                a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) unknown_var)                     ((_ is CelUnknown) (Bool true)))                 (CelUnknown (|_\|\|_| unknown_var (Bool true)))                 (ite a!3 CelError (Bool false))))) (let ((a!5 (and ((_ is CelUnknown) (ite a!1 (Bool true) a!4))                 ((_ is CelUnknown) (Bool true)))))   (not a!5))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (or (and ((_ is Bool) unknown_var) (getBool unknown_var))                (and ((_ is Bool) (Bool true)) (getBool (Bool true)))))       (a!2 (not (or ((_ is Bool) (Bool true)) ((_ is CelUnknown) (Bool true)))))) (let ((a!3 (or (not (or ((_ is Bool) unknown_var)                         ((_ is CelUnknown) unknown_var)))                a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) unknown_var)                     ((_ is CelUnknown) (Bool true)))                 (CelUnknown (|_\|\|_| unknown_var (Bool true)))                 (ite a!3 CelError (Bool false)))))   (not (= (ite a!1 (Bool true) a!4) (Bool true)))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
