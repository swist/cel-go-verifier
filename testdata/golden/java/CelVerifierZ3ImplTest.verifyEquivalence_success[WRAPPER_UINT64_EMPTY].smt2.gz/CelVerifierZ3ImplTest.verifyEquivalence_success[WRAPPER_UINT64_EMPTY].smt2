;; query 1 verifyEquivalence
(push)
(assert (let ((a!1 (or (> (getUint (Uint 0)) 18446744073709551615)                (< (getUint (Uint 0)) 0)))) (let ((a!2 (not (and ((_ is Uint) (Uint 0)) (not a!1)))))   (not (= (ite a!2 CelError (Uint 0)) (Uint 0))))))
(assert (let ((a!1 (or (> (getUint (Uint 0)) 18446744073709551615)                (< (getUint (Uint 0)) 0)))) (let ((a!2 (not (and ((_ is Uint) (Uint 0)) (not a!1))))) (let ((a!3 (and ((_ is CelUnknown) (ite a!2 CelError (Uint 0)))                 ((_ is CelUnknown) (Uint 0)))))   (not a!3)))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (or (> (getUint (Uint 0)) 18446744073709551615)                (< (getUint (Uint 0)) 0)))) (let ((a!2 (not (and ((_ is Uint) (Uint 0)) (not a!1)))))   (not (= (ite a!2 CelError (Uint 0)) (Uint 0))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
