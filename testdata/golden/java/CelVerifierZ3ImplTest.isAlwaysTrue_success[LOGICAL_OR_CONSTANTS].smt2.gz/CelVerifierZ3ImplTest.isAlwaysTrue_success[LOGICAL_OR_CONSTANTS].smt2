;; query 1 isAlwaysTrue
(push)
(assert (let ((a!1 (or (and ((_ is Bool) (Bool true)) (getBool (Bool true)))                (and ((_ is Bool) (Bool false)) (getBool (Bool false)))))       (a!2 (not (or ((_ is Bool) (Bool true)) ((_ is CelUnknown) (Bool true)))))       (a!3 (not (or ((_ is Bool) (Bool false)) ((_ is CelUnknown) (Bool false)))))) (let ((a!4 (ite (or ((_ is CelUnknown) (Bool true))                     ((_ is CelUnknown) (Bool false)))                 (ite ((_ is CelUnknown) (Bool true)) (Bool true) (Bool false))                 (ite (or a!2 a!3) CelError (Bool false))))) (let ((a!5 (and ((_ is Bool) (ite a!1 (Bool true) a!4))                 (getBool (ite a!1 (Bool true) a!4)))))   (not a!5)))))
(assert (not false))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (or (and ((_ is Bool) (Bool true)) (getBool (Bool true)))                (and ((_ is Bool) (Bool false)) (getBool (Bool false)))))       (a!2 (not (or ((_ is Bool) (Bool true)) ((_ is CelUnknown) (Bool true)))))       (a!3 (not (or ((_ is Bool) (Bool false)) ((_ is CelUnknown) (Bool false)))))) (let ((a!4 (ite (or ((_ is CelUnknown) (Bool true))                     ((_ is CelUnknown) (Bool false)))                 (ite ((_ is CelUnknown) (Bool true)) (Bool true) (Bool false))                 (ite (or a!2 a!3) CelError (Bool false))))) (let ((a!5 (and ((_ is Bool) (ite a!1 (Bool true) a!4))                 (getBool (ite a!1 (Bool true) a!4)))))   (not a!5)))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
