;; query 1 verifyEquivalence
(assert (let ((a!1 (not (or (> (getInt !fn_request_overload) 9223372036854775807)                     (< (getInt !fn_request_overload) (- 9223372036854775808)))))       (a!2 (not (or (> (getUint !fn_request_overload) 18446744073709551615)                     (< (getUint !fn_request_overload) 0))))       (a!3 (Double (ite (fp.isNaN (getDouble !fn_request_overload))                         (_ NaN 11 53)                         (getDouble !fn_request_overload))))       (a!5 (not (or (> (getTimestamp !fn_request_overload)                        253402300799999999999)                     (< (getTimestamp !fn_request_overload)                        (- 62135596800000000000)))))       (a!6 (not (or (> (getDuration !fn_request_overload) 315576000000999999999)                     (< (getDuration !fn_request_overload)                        (- 315576000000999999999)))))) (let ((a!4 (=> (and ((_ is Double) !fn_request_overload)                     (fp.isNaN (getDouble !fn_request_overload)))                (= !fn_request_overload a!3))))   (or ((_ is CelError) !fn_request_overload)       ((_ is CelUnknown) !fn_request_overload)       (and (=> ((_ is Int) !fn_request_overload) a!1)            (=> ((_ is Uint) !fn_request_overload) a!2)            a!4            (=> ((_ is Timestamp) !fn_request_overload) a!5)            (=> ((_ is Duration) !fn_request_overload) a!6))))))
(assert (not ((_ is CelUnknown) !fn_request_overload)))
(assert (not ((_ is CelError) !fn_request_overload)))
(assert !approx!0)
(assert !approx!1)
(push)
(assert (not (= !fn_request_overload !fn_request_overload)))
(assert (not (or !approx!0          !approx!1          (and ((_ is CelUnknown) !fn_request_overload)               ((_ is CelUnknown) !fn_request_overload)))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (not (= !fn_request_overload !fn_request_overload)))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
