;; query 1 verifyEquivalence
(assert (not ((_ is CelError) x)))
(assert (not ((_ is CelUnknown) x)))
(assert (let ((a!1 (not (or (> (getInt x) 9223372036854775807)                     (< (getInt x) (- 9223372036854775808))))))   (or ((_ is CelError) x) ((_ is CelUnknown) x) (and ((_ is Int) x) a!1))))
(push)
(assert (let ((a!1 (or (> (- (getInt x)) 9223372036854775807)                (< (- (getInt x)) (- 9223372036854775808))))) (let ((a!2 (ite a!1 CelError (Int (- (getInt x)))))) (let ((a!3 (ite (or ((_ is CelUnknown) x))                 (CelUnknown (-_ x))                 (ite (or ((_ is CelError) x)) CelError a!2)))) (let ((a!4 (ite (or ((_ is CelUnknown) x))                 (CelUnknown (-_ x))                 (ite (or ((_ is CelError) x))                      CelError                      (ite ((_ is Int) x) a!2 a!3))))) (let ((a!5 (Bool (and (>= (getInt a!4) 5) (<= (getInt a!4) 5))))) (let ((a!6 (ite (or ((_ is CelUnknown) a!4))                 (CelUnknown (_==_ a!4 (Int 5)))                 (ite (or ((_ is CelError) a!4)) CelError a!5))))   (not (= a!6 a!6)))))))))
(assert (let ((a!1 (or (> (- (getInt x)) 9223372036854775807)                (< (- (getInt x)) (- 9223372036854775808))))) (let ((a!2 (ite a!1 CelError (Int (- (getInt x)))))) (let ((a!3 (ite (or ((_ is CelUnknown) x))                 (CelUnknown (-_ x))                 (ite (or ((_ is CelError) x)) CelError a!2)))) (let ((a!4 (ite (or ((_ is CelUnknown) x))                 (CelUnknown (-_ x))                 (ite (or ((_ is CelError) x))                      CelError                      (ite ((_ is Int) x) a!2 a!3))))) (let ((a!5 (and ((_ is CelUnknown) a!4) (not (ite ((_ is Int) x) false false))))       (a!6 (and ((_ is CelError) a!4)                 (not (ite ((_ is Int) x) false false))                 (not ((_ is CelUnknown) a!4))))       (a!8 (Bool (and (>= (getInt a!4) 5) (<= (getInt a!4) 5))))) (let ((a!7 (or a!5 a!6 (not (ite ((_ is Int) x) false false))))       (a!9 (ite (or ((_ is CelUnknown) a!4))                 (CelUnknown (_==_ a!4 (Int 5)))                 (ite (or ((_ is CelError) a!4)) CelError a!8))))   (not (or (not a!7)            (not a!7)            (and ((_ is CelUnknown) a!9) ((_ is CelUnknown) a!9)))))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (or (> (- (getInt x)) 9223372036854775807)                (< (- (getInt x)) (- 9223372036854775808))))) (let ((a!2 (ite a!1 CelError (Int (- (getInt x)))))) (let ((a!3 (ite (or ((_ is CelUnknown) x))                 (CelUnknown (-_ x))                 (ite (or ((_ is CelError) x)) CelError a!2)))) (let ((a!4 (ite (or ((_ is CelUnknown) x))                 (CelUnknown (-_ x))                 (ite (or ((_ is CelError) x))                      CelError                      (ite ((_ is Int) x) a!2 a!3))))) (let ((a!5 (Bool (and (>= (getInt a!4) 5) (<= (getInt a!4) 5))))) (let ((a!6 (ite (or ((_ is CelUnknown) a!4))                 (CelUnknown (_==_ a!4 (Int 5)))                 (ite (or ((_ is CelError) a!4)) CelError a!5))))   (not (= a!6 a!6)))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
