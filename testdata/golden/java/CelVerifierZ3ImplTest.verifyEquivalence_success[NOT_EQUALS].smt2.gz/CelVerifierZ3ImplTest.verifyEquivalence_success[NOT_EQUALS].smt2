;; query 1 verifyEquivalence
(assert (not ((_ is CelError) x)))
(assert (not ((_ is CelUnknown) x)))
(assert (let ((a!1 (not (or (> (getInt x) 9223372036854775807)                     (< (getInt x) (- 9223372036854775808))))))   (or ((_ is CelError) x) ((_ is CelUnknown) x) (and ((_ is Int) x) a!1))))
(assert (not ((_ is CelError) y)))
(assert (not ((_ is CelUnknown) y)))
(assert (let ((a!1 (not (or (> (getInt y) 9223372036854775807)                     (< (getInt y) (- 9223372036854775808))))))   (or ((_ is CelError) y) ((_ is CelUnknown) y) (and ((_ is Int) y) a!1))))
(push)
(assert (let ((a!1 (Bool (not (= (getInt x) (getInt y)))))) (let ((a!2 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) y))                 (CelUnknown (_!=_ x y))                 (ite (or ((_ is CelError) x) ((_ is CelError) y)) CelError a!1))))   (not (= a!2 a!2)))))
(assert (let ((a!1 (Bool (not (= (getInt x) (getInt y)))))) (let ((a!2 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) y))                 (CelUnknown (_!=_ x y))                 (ite (or ((_ is CelError) x) ((_ is CelError) y)) CelError a!1))))   (not (and ((_ is CelUnknown) a!2) ((_ is CelUnknown) a!2))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (Bool (not (= (getInt x) (getInt y)))))) (let ((a!2 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) y))                 (CelUnknown (_!=_ x y))                 (ite (or ((_ is CelError) x) ((_ is CelError) y)) CelError a!1))))   (not (= a!2 a!2)))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
