;; query 1 verifyEquivalence
(push)
(assert (let ((a!1 (ite (not ((_ is Bool) (Bool false))) CelError (Bool false))))   (not (= a!1 (Bool false)))))
(assert (let ((a!1 (ite (not ((_ is Bool) (Bool false))) CelError (Bool false))))   (not (and ((_ is CelUnknown) a!1) ((_ is CelUnknown) (Bool false))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (not ((_ is Bool) (Bool false))) CelError (Bool false))))   (not (= a!1 (Bool false)))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
