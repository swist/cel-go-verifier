;; query 1 verifyEquivalence
(assert (not ((_ is CelError) d)))
(assert (not ((_ is CelUnknown) d)))
(assert (let ((a!1 (Double (ite (fp.isNaN (getDouble d)) (_ NaN 11 53) (getDouble d))))) (let ((a!2 (and ((_ is Double) d) (=> (fp.isNaN (getDouble d)) (= d a!1)))))   (or ((_ is CelError) d) ((_ is CelUnknown) d) a!2))))
(push)
(assert (let ((a!1 (Bool (not (fp.eq (getDouble d) (getDouble d)))))) (let ((a!2 (ite (or ((_ is CelUnknown) d) ((_ is CelUnknown) d))                 (CelUnknown (_!=_ d d))                 (ite (or ((_ is CelError) d) ((_ is CelError) d)) CelError a!1))))   (not (= a!2 (Bool false))))))
(assert (let ((a!1 (Bool (not (fp.eq (getDouble d) (getDouble d)))))) (let ((a!2 (ite (or ((_ is CelUnknown) d) ((_ is CelUnknown) d))                 (CelUnknown (_!=_ d d))                 (ite (or ((_ is CelError) d) ((_ is CelError) d)) CelError a!1))))   (not (and ((_ is CelUnknown) a!2) ((_ is CelUnknown) (Bool false)))))))
(check-sat) ; SATISFIABLE
