;; query 1 isAlwaysTrue
(assert (not ((_ is CelError) x)))
(assert (not ((_ is CelUnknown) x)))
(assert (let ((a!1 (not (or (> (getInt x) 9223372036854775807)                     (< (getInt x) (- 9223372036854775808))))))   (or ((_ is CelError) x) ((_ is CelUnknown) x) (and ((_ is Int) x) a!1))))
(push)
(assert (let ((a!1 (Bool (> (getInt x) (getInt (Int 5)))))) (let ((a!2 (ite (and ((_ is Int) x) ((_ is Int) (Int 5)))                 a!1                 (ite (or ((_ is CelUnknown) x))                      (CelUnknown !generic_unknown)                      CelError)))) (let ((a!3 (ite (or ((_ is CelError) x) ((_ is CelError) (Int 5))) CelError a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) (Int 5)))                 (CelUnknown !generic_unknown)                 a!3)))   (not (and ((_ is Bool) a!4) (getBool a!4))))))))
(assert (let ((a!1 (ite (and ((_ is Int) x) ((_ is Int) (Int 5))) false false)))   (not a!1)))
(check-sat) ; SATISFIABLE
