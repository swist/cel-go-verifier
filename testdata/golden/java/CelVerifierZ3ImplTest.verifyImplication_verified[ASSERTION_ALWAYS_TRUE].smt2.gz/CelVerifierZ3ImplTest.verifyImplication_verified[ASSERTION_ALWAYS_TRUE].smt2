;; query 1 verifyImplication
(assert (not ((_ is CelError) dyn_var)))
(assert (not ((_ is CelUnknown) dyn_var)))
(assert (let ((a!1 (not (or (> (getInt dyn_var) 9223372036854775807)                     (< (getInt dyn_var) (- 9223372036854775808)))))       (a!2 (not (or (> (getUint dyn_var) 18446744073709551615)                     (< (getUint dyn_var) 0))))       (a!3 (Double (ite (fp.isNaN (getDouble dyn_var))                         (_ NaN 11 53)                         (getDouble dyn_var))))       (a!5 (not (or (> (getTimestamp dyn_var) 253402300799999999999)                     (< (getTimestamp dyn_var) (- 62135596800000000000)))))       (a!6 (not (or (> (getDuration dyn_var) 315576000000999999999)                     (< (getDuration dyn_var) (- 315576000000999999999)))))) (let ((a!4 (=> (and ((_ is Double) dyn_var) (fp.isNaN (getDouble dyn_var)))                (= dyn_var a!3))))   (or ((_ is CelError) dyn_var)       ((_ is CelUnknown) dyn_var)       (and (=> ((_ is Int) dyn_var) a!1)            (=> ((_ is Uint) dyn_var) a!2)            a!4            (=> ((_ is Timestamp) dyn_var) a!5)            (=> ((_ is Duration) dyn_var) a!6))))))
(push)
(assert (let ((a!1 (ite (or ((_ is CelUnknown) dyn_var)                     ((_ is List) dyn_var)                     ((_ is Map) dyn_var))                 (CelUnknown (!trunc_92a9e9414a1a8f85 dyn_var))                 CelError))       (a!2 (not (and ((_ is Bool) (Bool true)) (getBool (Bool true))))))   (and ((_ is Bool) a!1) (getBool a!1) a!2)))
(assert (not (or ((_ is List) dyn_var) ((_ is Map) dyn_var))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (or ((_ is CelUnknown) dyn_var)                     ((_ is List) dyn_var)                     ((_ is Map) dyn_var))                 (CelUnknown (!trunc_92a9e9414a1a8f85 dyn_var))                 CelError))       (a!2 (not (and ((_ is Bool) (Bool true)) (getBool (Bool true))))))   (and ((_ is Bool) a!1) (getBool a!1) a!2)))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (or ((_ is CelUnknown) dyn_var)                     (or ((_ is List) dyn_var) ((_ is Map) dyn_var)))                 (CelUnknown (!trunc_92a9e9414a1a8f85 dyn_var))                 CelError))       (a!2 (not (and ((_ is Bool) (Bool true))                      (getBool (Bool true))                      (not false)))))   (and ((_ is CelUnknown) a!1)        (or ((_ is List) dyn_var) ((_ is Map) dyn_var))        a!2)))
(assert (or ((_ is List) dyn_var) ((_ is Map) dyn_var)))
(check-sat) ; UNSATISFIABLE
(pop)
