;; query 1 isSatisfiable
(assert (not ((_ is CelError) d)))
(assert (not ((_ is CelUnknown) d)))
(assert (let ((a!1 (Double (ite (fp.isNaN (getDouble d)) (_ NaN 11 53) (getDouble d))))) (let ((a!2 (and ((_ is Double) d) (=> (fp.isNaN (getDouble d)) (= d a!1)))))   (or ((_ is CelError) d) ((_ is CelUnknown) d) a!2))))
(push)
(assert (let ((a!1 (Bool (fp.gt (getDouble d)                         (getDouble (Double (fp #b0 #b11111111110 #xfffffffffffff))))))) (let ((a!2 (ite (and ((_ is Double) d)                      ((_ is Double)                        (Double (fp #b0 #b11111111110 #xfffffffffffff))))                 a!1                 (ite (or ((_ is CelUnknown) d))                      (CelUnknown !generic_unknown)                      CelError)))) (let ((a!3 (ite (or ((_ is CelError) d)                     ((_ is CelError)                       (Double (fp #b0 #b11111111110 #xfffffffffffff))))                 CelError                 a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) d)                     ((_ is CelUnknown)                       (Double (fp #b0 #b11111111110 #xfffffffffffff))))                 (CelUnknown !generic_unknown)                 a!3)))   (and ((_ is Bool) a!4) (getBool a!4)))))))
(assert (let ((a!1 (ite (and ((_ is Double) d)                      ((_ is Double)                        (Double (fp #b0 #b11111111110 #xfffffffffffff))))                 false                 false)))   (not a!1)))
(check-sat) ; SATISFIABLE
