;; query 1 verifyEquivalence
(assert (not ((_ is CelError) x)))
(assert (not ((_ is CelUnknown) x)))
(assert (let ((a!1 (not (or (> (getInt x) 9223372036854775807)                     (< (getInt x) (- 9223372036854775808))))))   (or ((_ is CelError) x) ((_ is CelUnknown) x) (and ((_ is Int) x) a!1))))
(assert (not ((_ is CelError) y)))
(assert (not ((_ is CelUnknown) y)))
(assert (let ((a!1 (not (or (> (getInt y) 9223372036854775807)                     (< (getInt y) (- 9223372036854775808))))))   (or ((_ is CelError) y) ((_ is CelUnknown) y) (and ((_ is Int) y) a!1))))
(push)
(assert (let ((a!1 (div (ite (< (getInt x) 0) (- (getInt x)) (getInt x))                 (ite (< (getInt y) 0) (- (getInt y)) (getInt y))))) (let ((a!2 (ite (xor (< (getInt x) 0) (< (getInt y) 0)) (- a!1) a!1))) (let ((a!3 (Int (- (getInt x) (* a!2 (getInt y)))))) (let ((a!4 (ite (and ((_ is Int) x) ((_ is Int) y))                 (ite (= (getInt y) 0) CelError a!3)                 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) y))                      (CelUnknown (_%_ x y))                      CelError)))) (let ((a!5 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) y))                 (CelUnknown (_%_ x y))                 (ite (or ((_ is CelError) x) ((_ is CelError) y)) CelError a!4)))) (let ((a!6 (Bool (and (>= (getInt a!5) 5) (<= (getInt a!5) 5))))) (let ((a!7 (ite (or ((_ is CelUnknown) a!5))                 (CelUnknown (_==_ a!5 (Int 5)))                 (ite (or ((_ is CelError) a!5)) CelError a!6))))   (not (= a!7 a!7))))))))))
(assert (let ((a!1 (div (ite (< (getInt x) 0) (- (getInt x)) (getInt x))                 (ite (< (getInt y) 0) (- (getInt y)) (getInt y))))       (a!6 (not (ite (and ((_ is Int) x) ((_ is Int) y)) false false)))) (let ((a!2 (ite (xor (< (getInt x) 0) (< (getInt y) 0)) (- a!1) a!1))) (let ((a!3 (Int (- (getInt x) (* a!2 (getInt y)))))) (let ((a!4 (ite (and ((_ is Int) x) ((_ is Int) y))                 (ite (= (getInt y) 0) CelError a!3)                 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) y))                      (CelUnknown (_%_ x y))                      CelError)))) (let ((a!5 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) y))                 (CelUnknown (_%_ x y))                 (ite (or ((_ is CelError) x) ((_ is CelError) y)) CelError a!4)))) (let ((a!7 (or (and ((_ is CelUnknown) a!5) a!6)                (and ((_ is CelError) a!5) a!6 (not ((_ is CelUnknown) a!5)))                a!6))       (a!8 (Bool (and (>= (getInt a!5) 5) (<= (getInt a!5) 5))))) (let ((a!9 (ite (or ((_ is CelUnknown) a!5))                 (CelUnknown (_==_ a!5 (Int 5)))                 (ite (or ((_ is CelError) a!5)) CelError a!8))))   (not (or (not a!7)            (not a!7)            (and ((_ is CelUnknown) a!9) ((_ is CelUnknown) a!9))))))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (div (ite (< (getInt x) 0) (- (getInt x)) (getInt x))                 (ite (< (getInt y) 0) (- (getInt y)) (getInt y))))) (let ((a!2 (ite (xor (< (getInt x) 0) (< (getInt y) 0)) (- a!1) a!1))) (let ((a!3 (Int (- (getInt x) (* a!2 (getInt y)))))) (let ((a!4 (ite (and ((_ is Int) x) ((_ is Int) y))                 (ite (= (getInt y) 0) CelError a!3)                 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) y))                      (CelUnknown (_%_ x y))                      CelError)))) (let ((a!5 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) y))                 (CelUnknown (_%_ x y))                 (ite (or ((_ is CelError) x) ((_ is CelError) y)) CelError a!4)))) (let ((a!6 (Bool (and (>= (getInt a!5) 5) (<= (getInt a!5) 5))))) (let ((a!7 (ite (or ((_ is CelUnknown) a!5))                 (CelUnknown (_==_ a!5 (Int 5)))                 (ite (or ((_ is CelError) a!5)) CelError a!6))))   (not (= a!7 a!7))))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
