;; query 1 isSatisfiable
(assert (not ((_ is CelError) x)))
(assert (not ((_ is CelUnknown) x)))
(assert (let ((a!1 (not (or (> (getInt x) 9223372036854775807)                     (< (getInt x) (- 9223372036854775808))))))   (or ((_ is CelError) x) ((_ is CelUnknown) x) (and ((_ is Int) x) a!1))))
(push)
(assert (let ((a!1 (Bool (and (>= (getInt x) 9223372036854775807)                       (<= (getInt x) 9223372036854775807))))) (let ((a!2 (ite (or ((_ is CelUnknown) x))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) x)) CelError a!1))))   (and ((_ is Bool) a!2) (getBool a!2)))))
(assert (not false))
(check-sat) ; SATISFIABLE
