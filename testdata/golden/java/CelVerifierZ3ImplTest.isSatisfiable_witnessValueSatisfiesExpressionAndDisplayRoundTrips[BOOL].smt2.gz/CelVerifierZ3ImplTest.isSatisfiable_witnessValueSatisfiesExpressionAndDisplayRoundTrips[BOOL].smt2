;; query 1 isSatisfiable
(assert (not ((_ is CelError) a)))
(assert (not ((_ is CelUnknown) a)))
(assert (or ((_ is CelError) a) ((_ is CelUnknown) a) ((_ is Bool) a)))
(push)
(assert (and ((_ is Bool) a) (getBool a)))
(assert (not false))
(check-sat) ; SATISFIABLE
