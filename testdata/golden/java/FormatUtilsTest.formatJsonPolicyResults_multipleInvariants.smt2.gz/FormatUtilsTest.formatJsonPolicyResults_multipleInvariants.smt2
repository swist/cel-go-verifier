;; query 1 isSatisfiable
(push)
(assert (and ((_ is Bool) (Bool true)) (getBool (Bool true))))
(assert (not false))
(check-sat) ; SATISFIABLE
;; query 2 isAlwaysTrue
(assert (or ((_ is Int) (string_to_int64 (String "123")))     ((_ is CelError) (string_to_int64 (String "123")))))
(assert (let ((a!1 (> (getInt (string_to_int64 (String "123"))) 9223372036854775807))       (a!2 (< (getInt (string_to_int64 (String "123"))) (- 9223372036854775808))))   (=> ((_ is Int) (string_to_int64 (String "123"))) (not (or a!1 a!2)))))
(assert !approx!0)
(push)
(assert (let ((a!1 (ite (or ((_ is CelError) (String "123")))                 CelError                 (ite ((_ is String) (String "123"))                      (string_to_int64 (String "123"))                      CelError)))) (let ((a!2 (ite (or ((_ is CelUnknown) (String "123")))                 (CelUnknown !generic_unknown)                 a!1))) (let ((a!3 (Bool (and (>= (getInt a!2) 123) (<= (getInt a!2) 123))))) (let ((a!4 (ite (or ((_ is CelUnknown) a!2))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) a!2)) CelError a!3))))   (not (and ((_ is Bool) a!4) (getBool a!4))))))))
(assert (let ((a!1 (ite (or ((_ is CelError) (String "123")))                 CelError                 (ite ((_ is String) (String "123"))                      (string_to_int64 (String "123"))                      CelError)))       (a!3 (not (ite ((_ is String) (String "123")) !approx!0 false)))) (let ((a!2 (ite (or ((_ is CelUnknown) (String "123")))                 (CelUnknown !generic_unknown)                 a!1))) (let ((a!4 (or (and ((_ is CelUnknown) a!2) a!3)                (and ((_ is CelError) a!2) a!3 (not ((_ is CelUnknown) a!2)))                a!3)))   (not (not a!4))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (or ((_ is CelError) (String "123")))                 CelError                 (ite ((_ is String) (String "123"))                      (string_to_int64 (String "123"))                      CelError)))) (let ((a!2 (ite (or ((_ is CelUnknown) (String "123")))                 (CelUnknown !generic_unknown)                 a!1))) (let ((a!3 (Bool (and (>= (getInt a!2) 123) (<= (getInt a!2) 123))))) (let ((a!4 (ite (or ((_ is CelUnknown) a!2))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) a!2)) CelError a!3))))   (not (and ((_ is Bool) a!4) (getBool a!4))))))))
(check-sat) ; SATISFIABLE
