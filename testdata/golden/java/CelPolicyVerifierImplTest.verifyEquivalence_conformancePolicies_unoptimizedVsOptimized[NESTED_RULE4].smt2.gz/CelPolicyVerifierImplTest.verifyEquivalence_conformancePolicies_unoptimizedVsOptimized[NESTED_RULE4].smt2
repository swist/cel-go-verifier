;; query 1 verifyEquivalence
(assert (not ((_ is CelError) x)))
(assert (not ((_ is CelUnknown) x)))
(assert (let ((a!1 (not (or (> (getInt x) 9223372036854775807)                     (< (getInt x) (- 9223372036854775808))))))   (or ((_ is CelError) x) ((_ is CelUnknown) x) (and ((_ is Int) x) a!1))))
(push)
(assert (let ((a!1 (Bool (> (getInt x) (getInt (Int 0)))))       (a!2 (ite (or ((_ is CelUnknown) x))                 (CelUnknown (_>_ x (Int 0)))                 CelError))) (let ((a!3 (ite (and ((_ is Int) x) ((_ is Int) (Int 0))) a!1 a!2))) (let ((a!4 (ite (or ((_ is CelError) x) ((_ is CelError) (Int 0))) CelError a!3))) (let ((a!5 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) (Int 0)))                 (CelUnknown (_>_ x (Int 0)))                 a!4))) (let ((a!6 (ite ((_ is CelError) a!5)                 CelError                 (ite (and ((_ is Bool) a!5) (getBool a!5))                      (Bool true)                      (Bool false))))) (let ((a!7 (ite ((_ is CelUnknown) a!5)                 (CelUnknown (|_?_:_| a!5 (Bool true) (Bool false)))                 a!6)))   (not (= a!7 a!7)))))))))
(assert (let ((a!1 (Bool (> (getInt x) (getInt (Int 0)))))       (a!2 (ite (or ((_ is CelUnknown) x))                 (CelUnknown (_>_ x (Int 0)))                 CelError))       (a!6 (ite (and ((_ is Int) x) ((_ is Int) (Int 0))) false false))) (let ((a!3 (ite (and ((_ is Int) x) ((_ is Int) (Int 0))) a!1 a!2))) (let ((a!4 (ite (or ((_ is CelError) x) ((_ is CelError) (Int 0))) CelError a!3))) (let ((a!5 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) (Int 0)))                 (CelUnknown (_>_ x (Int 0)))                 a!4))) (let ((a!7 (ite ((_ is CelError) a!5)                 (not (and ((_ is CelError) a!5) (not a!6)))                 (or a!6 false)))       (a!9 (ite ((_ is CelError) a!5)                 CelError                 (ite (and ((_ is Bool) a!5) (getBool a!5))                      (Bool true)                      (Bool false))))) (let ((a!8 (ite ((_ is CelUnknown) a!5)                 (not (and ((_ is CelUnknown) a!5) (not a!6)))                 a!7))       (a!10 (ite ((_ is CelUnknown) a!5)                  (CelUnknown (|_?_:_| a!5 (Bool true) (Bool false)))                  a!9)))   (not (or a!8 a!8 (and ((_ is CelUnknown) a!10) ((_ is CelUnknown) a!10)))))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (Bool (> (getInt x) (getInt (Int 0)))))       (a!2 (ite (or ((_ is CelUnknown) x))                 (CelUnknown (_>_ x (Int 0)))                 CelError))) (let ((a!3 (ite (and ((_ is Int) x) ((_ is Int) (Int 0))) a!1 a!2))) (let ((a!4 (ite (or ((_ is CelError) x) ((_ is CelError) (Int 0))) CelError a!3))) (let ((a!5 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) (Int 0)))                 (CelUnknown (_>_ x (Int 0)))                 a!4))) (let ((a!6 (ite ((_ is CelError) a!5)                 CelError                 (ite (and ((_ is Bool) a!5) (getBool a!5))                      (Bool true)                      (Bool false))))) (let ((a!7 (ite ((_ is CelUnknown) a!5)                 (CelUnknown (|_?_:_| a!5 (Bool true) (Bool false)))                 a!6)))   (not (= a!7 a!7)))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
