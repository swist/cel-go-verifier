;; query 1 verifyEquivalence
(assert (not ((_ is CelError) string_int_map)))
(assert (not ((_ is CelUnknown) string_int_map)))
(assert (let ((a!1 (<= (seq.len (map_keys (getMapRef string_int_map))) 0))       (a!3 (> (seq.len (map_keys (getMapRef string_int_map))) 0))) (let ((a!2 (=> a!1                (= (map_presence (getMapRef string_int_map))                   ((as const (Array CelValue Bool)) false)))))   (or ((_ is CelError) string_int_map)       ((_ is CelUnknown) string_int_map)       (and ((_ is Map) string_int_map)            a!2            (=> a!3 (!has_truncated_type_constraint string_int_map)))))))
(assert (let ((a!1 (= (!mkMapRef (map_values (getMapRef string_int_map))                          (map_presence (getMapRef string_int_map)))               (getMapRef string_int_map))))   (=> ((_ is Map) string_int_map) a!1)))
(push)
(assert (let ((a!1 (> (seq.len (map_keys (getMapRef string_int_map))) 0))) (let ((a!2 (ite (or false (and ((_ is Map) string_int_map) a!1))                 (CelUnknown (!trunc_e47a17662b2f4bad string_int_map))                 (Bool false)))) (let ((a!3 (ite ((_ is CelError) string_int_map)                 CelError                 (ite ((_ is CelUnknown) string_int_map)                      (CelUnknown (!trunc_e47a17662b2f4bad string_int_map))                      a!2))))   (not (= a!3 a!3))))))
(assert (let ((a!1 (> (seq.len (map_keys (getMapRef string_int_map))) 0))) (let ((a!2 (ite (or false (and ((_ is Map) string_int_map) a!1))                 (or false (and ((_ is Map) string_int_map) a!1) false)                 false))       (a!3 (ite (or false (and ((_ is Map) string_int_map) a!1))                 (CelUnknown (!trunc_e47a17662b2f4bad string_int_map))                 (Bool false)))) (let ((a!4 (ite ((_ is CelError) string_int_map)                 CelError                 (ite ((_ is CelUnknown) string_int_map)                      (CelUnknown (!trunc_e47a17662b2f4bad string_int_map))                      a!3)))) (let ((a!5 (or (ite (or ((_ is CelError) string_int_map)                         ((_ is CelUnknown) string_int_map))                     false                     a!2)                (ite (or ((_ is CelError) string_int_map)                         ((_ is CelUnknown) string_int_map))                     false                     a!2)                (and ((_ is CelUnknown) a!4) ((_ is CelUnknown) a!4)))))   (not a!5))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (> (seq.len (map_keys (getMapRef string_int_map))) 0))) (let ((a!2 (ite (or false (and ((_ is Map) string_int_map) a!1))                 (CelUnknown (!trunc_e47a17662b2f4bad string_int_map))                 (Bool false)))) (let ((a!3 (ite ((_ is CelError) string_int_map)                 CelError                 (ite ((_ is CelUnknown) string_int_map)                      (CelUnknown (!trunc_e47a17662b2f4bad string_int_map))                      a!2))))   (not (= a!3 a!3))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert (let ((a!1 (> (seq.len (map_keys (getMapRef string_int_map))) 0)))   (or (and ((_ is Map) string_int_map) a!1)       (and ((_ is Map) string_int_map) a!1))))
(check-sat) ; UNSATISFIABLE
(pop)
