;; query 1 verifyEquivalence
(push)
(assert (let ((a!1 (ite (not ((_ is Bool) (Bool true))) CelError (Bool true))))   (not (= a!1 (Bool true)))))
(assert (let ((a!1 (ite (not ((_ is Bool) (Bool true))) CelError (Bool true))))   (not (and ((_ is CelUnknown) a!1) ((_ is CelUnknown) (Bool true))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (not ((_ is Bool) (Bool true))) CelError (Bool true))))   (not (= a!1 (Bool true)))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
