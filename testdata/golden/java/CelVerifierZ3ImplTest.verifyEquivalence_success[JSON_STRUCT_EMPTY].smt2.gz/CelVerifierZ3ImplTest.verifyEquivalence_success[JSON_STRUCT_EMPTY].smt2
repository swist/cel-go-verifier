;; query 1 verifyEquivalence
(assert (= (map_presence !empty_map!0) ((as const (Array CelValue Bool)) false)))
(assert (= (map_values !empty_map!0)    ((as const (Array CelValue CelValue)) (CelUnknown !generic_unknown))))
(assert (= (map_keys !empty_map!0) (as seq.empty (Seq CelValue))))
(assert (= (!mkMapRef (map_values !empty_map!0) (map_presence !empty_map!0))    !empty_map!0))
(assert (= (map_values !mapRef_!1)    ((as const (Array CelValue CelValue)) (CelUnknown !generic_unknown))))
(assert (= (map_presence !mapRef_!1) ((as const (Array CelValue Bool)) false)))
(assert (= (map_keys !mapRef_!1) (as seq.empty (Seq CelValue))))
(assert (= (!mkMapRef (map_values !mapRef_!1) (map_presence !mapRef_!1)) !mapRef_!1))
(push)
(assert (not (= (Map !empty_map!0) (ite false CelError (Map !mapRef_!1)))))
(assert (let ((a!1 (and ((_ is CelUnknown) (Map !empty_map!0))                 ((_ is CelUnknown) (ite false CelError (Map !mapRef_!1))))))   (not a!1)))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (not (= (Map !empty_map!0) (ite false CelError (Map !mapRef_!1)))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
