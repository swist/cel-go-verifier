;; query 1 isAlwaysTrue
(push)
(assert (let ((a!1 (Bool (str.suffixof (getString (String "def"))                                (getString (String "abcdef")))))) (let ((a!2 (ite (and ((_ is String) (String "abcdef"))                      ((_ is String) (String "def")))                 a!1                 CelError))) (let ((a!3 (ite (or ((_ is CelError) (String "abcdef"))                     ((_ is CelError) (String "def")))                 CelError                 a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) (String "abcdef"))                     ((_ is CelUnknown) (String "def")))                 (CelUnknown !generic_unknown)                 a!3)))   (not (and ((_ is Bool) a!4) (getBool a!4))))))))
(assert (let ((a!1 (ite (and ((_ is String) (String "abcdef"))                      ((_ is String) (String "def")))                 false                 false)))   (not a!1)))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (Bool (str.suffixof (getString (String "def"))                                (getString (String "abcdef")))))) (let ((a!2 (ite (and ((_ is String) (String "abcdef"))                      ((_ is String) (String "def")))                 a!1                 CelError))) (let ((a!3 (ite (or ((_ is CelError) (String "abcdef"))                     ((_ is CelError) (String "def")))                 CelError                 a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) (String "abcdef"))                     ((_ is CelUnknown) (String "def")))                 (CelUnknown !generic_unknown)                 a!3)))   (not (and ((_ is Bool) a!4) (getBool a!4))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
