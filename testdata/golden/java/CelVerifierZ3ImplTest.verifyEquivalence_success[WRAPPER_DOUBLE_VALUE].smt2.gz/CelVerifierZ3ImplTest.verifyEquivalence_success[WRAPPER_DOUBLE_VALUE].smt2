;; query 1 verifyEquivalence
(push)
(assert (let ((a!1 (ite (fp.isNaN (getDouble (Double (fp #b0 #b01111111111 #x8000000000000))))                 (_ NaN 11 53)                 (getDouble (Double (fp #b0 #b01111111111 #x8000000000000)))))) (let ((a!2 (=> (fp.isNaN (getDouble (Double (fp #b0 #b01111111111 #x8000000000000))))                (= (Double (fp #b0 #b01111111111 #x8000000000000)) (Double a!1))))) (let ((a!3 (not (and ((_ is Double)                        (Double (fp #b0 #b01111111111 #x8000000000000)))                      a!2))))   (not (= (ite a!3 CelError (Double (fp #b0 #b01111111111 #x8000000000000)))           (Double (fp #b0 #b01111111111 #x8000000000000))))))))
(assert (let ((a!1 (ite (fp.isNaN (getDouble (Double (fp #b0 #b01111111111 #x8000000000000))))                 (_ NaN 11 53)                 (getDouble (Double (fp #b0 #b01111111111 #x8000000000000)))))) (let ((a!2 (=> (fp.isNaN (getDouble (Double (fp #b0 #b01111111111 #x8000000000000))))                (= (Double (fp #b0 #b01111111111 #x8000000000000)) (Double a!1))))) (let ((a!3 (not (and ((_ is Double)                        (Double (fp #b0 #b01111111111 #x8000000000000)))                      a!2)))) (let ((a!4 (and ((_ is CelUnknown)                   (ite a!3                        CelError                        (Double (fp #b0 #b01111111111 #x8000000000000))))                 ((_ is CelUnknown)                   (Double (fp #b0 #b01111111111 #x8000000000000))))))   (not a!4))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (fp.isNaN (getDouble (Double (fp #b0 #b01111111111 #x8000000000000))))                 (_ NaN 11 53)                 (getDouble (Double (fp #b0 #b01111111111 #x8000000000000)))))) (let ((a!2 (=> (fp.isNaN (getDouble (Double (fp #b0 #b01111111111 #x8000000000000))))                (= (Double (fp #b0 #b01111111111 #x8000000000000)) (Double a!1))))) (let ((a!3 (not (and ((_ is Double)                        (Double (fp #b0 #b01111111111 #x8000000000000)))                      a!2))))   (not (= (ite a!3 CelError (Double (fp #b0 #b01111111111 #x8000000000000)))           (Double (fp #b0 #b01111111111 #x8000000000000))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
