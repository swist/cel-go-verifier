;; query 1 verifyEquivalence
(assert (not ((_ is CelError) port)))
(assert (not ((_ is CelUnknown) port)))
(assert (let ((a!1 (not (or (> (getInt port) 9223372036854775807)                     (< (getInt port) (- 9223372036854775808))))))   (or ((_ is CelError) port)       ((_ is CelUnknown) port)       (and ((_ is Int) port) a!1))))
(push)
(assert (let ((a!1 (Bool (and (>= (getInt port) 80) (<= (getInt port) 80))))) (let ((a!2 (ite (or ((_ is CelUnknown) port))                 (CelUnknown (_==_ port (Int 80)))                 (ite (or ((_ is CelError) port)) CelError a!1)))) (let ((a!3 (ite ((_ is CelError) a!2)                 CelError                 (ite (and ((_ is Bool) a!2) (getBool a!2))                      (Bool true)                      (Bool false))))) (let ((a!4 (ite ((_ is CelUnknown) a!2)                 (CelUnknown (|_?_:_| a!2 (Bool true) (Bool false)))                 a!3)))   (not (= a!4 a!4)))))))
(assert (let ((a!1 (Bool (and (>= (getInt port) 80) (<= (getInt port) 80))))) (let ((a!2 (ite (or ((_ is CelUnknown) port))                 (CelUnknown (_==_ port (Int 80)))                 (ite (or ((_ is CelError) port)) CelError a!1)))) (let ((a!3 (ite ((_ is CelError) a!2)                 (not (and ((_ is CelError) a!2) (not false)))                 (or false false)))       (a!5 (ite ((_ is CelError) a!2)                 CelError                 (ite (and ((_ is Bool) a!2) (getBool a!2))                      (Bool true)                      (Bool false))))) (let ((a!4 (ite ((_ is CelUnknown) a!2)                 (not (and ((_ is CelUnknown) a!2) (not false)))                 a!3))       (a!6 (ite ((_ is CelUnknown) a!2)                 (CelUnknown (|_?_:_| a!2 (Bool true) (Bool false)))                 a!5)))   (not (or a!4 a!4 (and ((_ is CelUnknown) a!6) ((_ is CelUnknown) a!6)))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (Bool (and (>= (getInt port) 80) (<= (getInt port) 80))))) (let ((a!2 (ite (or ((_ is CelUnknown) port))                 (CelUnknown (_==_ port (Int 80)))                 (ite (or ((_ is CelError) port)) CelError a!1)))) (let ((a!3 (ite ((_ is CelError) a!2)                 CelError                 (ite (and ((_ is Bool) a!2) (getBool a!2))                      (Bool true)                      (Bool false))))) (let ((a!4 (ite ((_ is CelUnknown) a!2)                 (CelUnknown (|_?_:_| a!2 (Bool true) (Bool false)))                 a!3)))   (not (= a!4 a!4)))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
