;; query 1 verifyEquivalence
(assert (not ((_ is CelError) a)))
(assert (or ((_ is CelUnknown) a)     ((_ is CelError) a)     ((_ is CelUnknown) a)     ((_ is Bool) a)))
(push)
(assert (let ((a!1 (and ((_ is Bool) (Bool true)) (not (getBool (Bool true)))))       (a!3 (not (or ((_ is Bool) (Bool true)) ((_ is CelUnknown) (Bool true)))))) (let ((a!2 (or (and ((_ is Bool) a) (not (getBool a))) a!1))       (a!4 (or (not (or ((_ is Bool) a) ((_ is CelUnknown) a))) a!3))) (let ((a!5 (ite (or ((_ is CelUnknown) a) ((_ is CelUnknown) (Bool true)))                 (CelUnknown (_&&_ a (Bool true)))                 (ite a!4 CelError (Bool true)))))   (not (= (ite a!2 (Bool false) a!5) a))))))
(assert (let ((a!1 (and ((_ is Bool) (Bool true)) (not (getBool (Bool true)))))       (a!3 (not (or ((_ is Bool) (Bool true)) ((_ is CelUnknown) (Bool true)))))) (let ((a!2 (or (and ((_ is Bool) a) (not (getBool a))) a!1))       (a!4 (or (not (or ((_ is Bool) a) ((_ is CelUnknown) a))) a!3))) (let ((a!5 (ite (or ((_ is CelUnknown) a) ((_ is CelUnknown) (Bool true)))                 (CelUnknown (_&&_ a (Bool true)))                 (ite a!4 CelError (Bool true))))) (let ((a!6 (and ((_ is CelUnknown) (ite a!2 (Bool false) a!5))                 ((_ is CelUnknown) a))))   (not a!6))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (and ((_ is Bool) (Bool true)) (not (getBool (Bool true)))))       (a!3 (not (or ((_ is Bool) (Bool true)) ((_ is CelUnknown) (Bool true)))))) (let ((a!2 (or (and ((_ is Bool) a) (not (getBool a))) a!1))       (a!4 (or (not (or ((_ is Bool) a) ((_ is CelUnknown) a))) a!3))) (let ((a!5 (ite (or ((_ is CelUnknown) a) ((_ is CelUnknown) (Bool true)))                 (CelUnknown (_&&_ a (Bool true)))                 (ite a!4 CelError (Bool true)))))   (not (= (ite a!2 (Bool false) a!5) a))))))
(check-sat) ; SATISFIABLE
