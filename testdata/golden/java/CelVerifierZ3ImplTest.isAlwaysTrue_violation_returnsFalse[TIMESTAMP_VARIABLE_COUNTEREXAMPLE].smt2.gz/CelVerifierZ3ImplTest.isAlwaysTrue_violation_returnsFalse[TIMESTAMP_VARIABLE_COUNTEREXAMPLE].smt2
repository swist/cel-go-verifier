;; query 1 isAlwaysTrue
(assert (not ((_ is CelError) ts)))
(assert (not ((_ is CelUnknown) ts)))
(assert (let ((a!1 (not (or (> (getTimestamp ts) 253402300799999999999)                     (< (getTimestamp ts) (- 62135596800000000000))))))   (or ((_ is CelError) ts)       ((_ is CelUnknown) ts)       (and ((_ is Timestamp) ts) a!1))))
(assert (let ((a!1 (= (!mkListRef (as_seq (getListRef ts))) (getListRef ts))))   (=> ((_ is List) ts) a!1)))
(assert (let ((a!1 (= (!mkMapRef (map_values (getMapRef ts))                          (map_presence (getMapRef ts)))               (getMapRef ts))))   (=> ((_ is Map) ts) a!1)))
(assert (let ((a!1 (= (!mkMsgRef (msg_type_name (getMessageRef ts))                          (msg_values (getMessageRef ts))                          (msg_presence (getMessageRef ts)))               (getMessageRef ts))))   (=> ((_ is Message) ts) a!1)))
(push)
(assert (let ((a!1 (and (= (map_presence (getMapRef ts)) (map_presence (getMapRef ts)))                 (= (map_values (getMapRef ts)) (map_values (getMapRef ts)))))       (a!2 (and (= (msg_type_name (getMessageRef ts))                    (msg_type_name (getMessageRef ts)))                 (= (msg_values (getMessageRef ts))                    (msg_values (getMessageRef ts)))                 (= (msg_presence (getMessageRef ts))                    (msg_presence (getMessageRef ts)))))) (let ((a!3 (ite (and ((_ is Message) ts) ((_ is Message) ts))                 a!2                 (ite (and ((_ is Double) ts) ((_ is Double) ts))                      (fp.eq (getDouble ts) (getDouble ts))                      (= ts ts))))) (let ((a!4 (ite (and ((_ is List) ts) ((_ is List) ts))                 (= (as_seq (getListRef ts)) (as_seq (getListRef ts)))                 (ite (and ((_ is Map) ts) ((_ is Map) ts)) a!1 a!3)))) (let ((a!5 (ite (or ((_ is CelUnknown) ts) ((_ is CelUnknown) ts))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) ts) ((_ is CelError) ts))                      CelError                      (Bool (not a!4))))))   (not (and ((_ is Bool) a!5) (getBool a!5))))))))
(assert (not false))
(check-sat) ; SATISFIABLE
