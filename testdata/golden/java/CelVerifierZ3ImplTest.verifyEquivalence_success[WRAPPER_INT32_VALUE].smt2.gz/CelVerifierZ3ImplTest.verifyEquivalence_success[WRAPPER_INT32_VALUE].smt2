;; query 1 verifyEquivalence
(push)
(assert (let ((a!1 (or (> (getInt (Int 42)) 9223372036854775807)                (< (getInt (Int 42)) (- 9223372036854775808))))) (let ((a!2 (and ((_ is Int) (Int 42))                 (not a!1)                 (>= (getInt (Int 42)) (- 2147483648))                 (<= (getInt (Int 42)) 2147483647))))   (not (= (ite (not a!2) CelError (Int 42)) (Int 42))))))
(assert (let ((a!1 (or (> (getInt (Int 42)) 9223372036854775807)                (< (getInt (Int 42)) (- 9223372036854775808))))) (let ((a!2 (and ((_ is Int) (Int 42))                 (not a!1)                 (>= (getInt (Int 42)) (- 2147483648))                 (<= (getInt (Int 42)) 2147483647)))) (let ((a!3 (and ((_ is CelUnknown) (ite (not a!2) CelError (Int 42)))                 ((_ is CelUnknown) (Int 42)))))   (not a!3)))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (or (> (getInt (Int 42)) 9223372036854775807)                (< (getInt (Int 42)) (- 9223372036854775808))))) (let ((a!2 (and ((_ is Int) (Int 42))                 (not a!1)                 (>= (getInt (Int 42)) (- 2147483648))                 (<= (getInt (Int 42)) 2147483647))))   (not (= (ite (not a!2) CelError (Int 42)) (Int 42))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
