;; query 1 verifyEquivalence
(push)
(assert (let ((a!1 (or (> (getUint (Uint 42)) 18446744073709551615)                (< (getUint (Uint 42)) 0)))) (let ((a!2 (and ((_ is Uint) (Uint 42))                 (not a!1)                 (>= (getUint (Uint 42)) 0)                 (<= (getUint (Uint 42)) 4294967295))))   (not (= (ite (not a!2) CelError (Uint 42)) (Uint 42))))))
(assert (let ((a!1 (or (> (getUint (Uint 42)) 18446744073709551615)                (< (getUint (Uint 42)) 0)))) (let ((a!2 (and ((_ is Uint) (Uint 42))                 (not a!1)                 (>= (getUint (Uint 42)) 0)                 (<= (getUint (Uint 42)) 4294967295)))) (let ((a!3 (and ((_ is CelUnknown) (ite (not a!2) CelError (Uint 42)))                 ((_ is CelUnknown) (Uint 42)))))   (not a!3)))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (or (> (getUint (Uint 42)) 18446744073709551615)                (< (getUint (Uint 42)) 0)))) (let ((a!2 (and ((_ is Uint) (Uint 42))                 (not a!1)                 (>= (getUint (Uint 42)) 0)                 (<= (getUint (Uint 42)) 4294967295))))   (not (= (ite (not a!2) CelError (Uint 42)) (Uint 42))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
