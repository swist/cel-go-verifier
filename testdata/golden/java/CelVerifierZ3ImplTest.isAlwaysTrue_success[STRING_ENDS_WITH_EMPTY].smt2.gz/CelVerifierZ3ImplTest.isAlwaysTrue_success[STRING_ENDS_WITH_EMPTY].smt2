;; query 1 isAlwaysTrue
(assert (not ((_ is CelError) role)))
(assert (not ((_ is CelUnknown) role)))
(assert (or ((_ is CelError) role) ((_ is CelUnknown) role) ((_ is String) role)))
(push)
(assert (let ((a!1 (Bool (str.suffixof (getString (String "")) (getString role))))) (let ((a!2 (ite (and ((_ is String) role) ((_ is String) (String "")))                 a!1                 (ite (or ((_ is CelUnknown) role))                      (CelUnknown !generic_unknown)                      CelError)))) (let ((a!3 (ite (or ((_ is CelError) role) ((_ is CelError) (String "")))                 CelError                 a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) role) ((_ is CelUnknown) (String "")))                 (CelUnknown !generic_unknown)                 a!3)))   (not (and ((_ is Bool) a!4) (getBool a!4))))))))
(assert (let ((a!1 (ite (and ((_ is String) role) ((_ is String) (String "")))                 false                 false)))   (not a!1)))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (Bool (str.suffixof (getString (String "")) (getString role))))) (let ((a!2 (ite (and ((_ is String) role) ((_ is String) (String "")))                 a!1                 (ite (or ((_ is CelUnknown) role))                      (CelUnknown !generic_unknown)                      CelError)))) (let ((a!3 (ite (or ((_ is CelError) role) ((_ is CelError) (String "")))                 CelError                 a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) role) ((_ is CelUnknown) (String "")))                 (CelUnknown !generic_unknown)                 a!3)))   (not (and ((_ is Bool) a!4) (getBool a!4))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
