;; query 1 isSatisfiable
(assert (not ((_ is CelError) by)))
(assert (not ((_ is CelUnknown) by)))
(assert (or ((_ is CelError) by) ((_ is CelUnknown) by) ((_ is Bytes) by)))
(push)
(assert (let ((a!1 (Bool (str.<= (getBytes by) (getBytes (Bytes "bytes")))))) (let ((a!2 (ite (and ((_ is Bytes) by) ((_ is Bytes) (Bytes "bytes")))                 a!1                 (ite (or ((_ is CelUnknown) by))                      (CelUnknown !generic_unknown)                      CelError)))) (let ((a!3 (ite (or ((_ is CelError) by) ((_ is CelError) (Bytes "bytes")))                 CelError                 a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) by) ((_ is CelUnknown) (Bytes "bytes")))                 (CelUnknown !generic_unknown)                 a!3)))   (and ((_ is Bool) a!4) (getBool a!4)))))))
(assert (let ((a!1 (ite (and ((_ is Bytes) by) ((_ is Bytes) (Bytes "bytes")))                 false                 false)))   (not a!1)))
(check-sat) ; SATISFIABLE
