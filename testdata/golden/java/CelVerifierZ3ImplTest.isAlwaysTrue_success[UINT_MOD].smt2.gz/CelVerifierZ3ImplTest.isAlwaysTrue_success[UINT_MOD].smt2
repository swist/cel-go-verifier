;; query 1 isAlwaysTrue
(push)
(assert (let ((a!1 (Uint (mod (getUint (Uint 1)) (getUint (Uint 1)))))) (let ((a!2 (ite (= (getUint (Uint 1)) 0) CelError a!1))) (let ((a!3 (ite (and ((_ is Uint) (Uint 1)) ((_ is Uint) (Uint 1)))                 a!2                 CelError))) (let ((a!4 (ite (or ((_ is CelError) (Uint 1)) ((_ is CelError) (Uint 1)))                 CelError                 a!3))) (let ((a!5 (ite (or ((_ is CelUnknown) (Uint 1)) ((_ is CelUnknown) (Uint 1)))                 (CelUnknown !generic_unknown)                 a!4))) (let ((a!6 (Bool (and (>= (getUint a!5) 0) (<= (getUint a!5) 0))))) (let ((a!7 (ite (or ((_ is CelUnknown) a!5))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) a!5)) CelError a!6))))   (not (and ((_ is Bool) a!7) (getBool a!7)))))))))))
(assert (let ((a!1 (Uint (mod (getUint (Uint 1)) (getUint (Uint 1)))))       (a!6 (ite (and ((_ is Uint) (Uint 1)) ((_ is Uint) (Uint 1))) false false))) (let ((a!2 (ite (= (getUint (Uint 1)) 0) CelError a!1))) (let ((a!3 (ite (and ((_ is Uint) (Uint 1)) ((_ is Uint) (Uint 1)))                 a!2                 CelError))) (let ((a!4 (ite (or ((_ is CelError) (Uint 1)) ((_ is CelError) (Uint 1)))                 CelError                 a!3))) (let ((a!5 (ite (or ((_ is CelUnknown) (Uint 1)) ((_ is CelUnknown) (Uint 1)))                 (CelUnknown !generic_unknown)                 a!4))) (let ((a!7 (or (and ((_ is CelUnknown) a!5) (not a!6))                (and ((_ is CelError) a!5)                     (not a!6)                     (not ((_ is CelUnknown) a!5)))                (not a!6))))   (not (not a!7)))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (Uint (mod (getUint (Uint 1)) (getUint (Uint 1)))))) (let ((a!2 (ite (= (getUint (Uint 1)) 0) CelError a!1))) (let ((a!3 (ite (and ((_ is Uint) (Uint 1)) ((_ is Uint) (Uint 1)))                 a!2                 CelError))) (let ((a!4 (ite (or ((_ is CelError) (Uint 1)) ((_ is CelError) (Uint 1)))                 CelError                 a!3))) (let ((a!5 (ite (or ((_ is CelUnknown) (Uint 1)) ((_ is CelUnknown) (Uint 1)))                 (CelUnknown !generic_unknown)                 a!4))) (let ((a!6 (Bool (and (>= (getUint a!5) 0) (<= (getUint a!5) 0))))) (let ((a!7 (ite (or ((_ is CelUnknown) a!5))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) a!5)) CelError a!6))))   (not (and ((_ is Bool) a!7) (getBool a!7)))))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
