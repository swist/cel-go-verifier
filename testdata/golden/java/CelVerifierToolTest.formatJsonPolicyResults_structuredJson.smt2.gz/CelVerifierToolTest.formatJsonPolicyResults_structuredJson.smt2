;; query 1 isSatisfiable
(push)
(assert (and ((_ is Bool) (Bool true)) (getBool (Bool true))))
(assert (not false))
(check-sat) ; SATISFIABLE
