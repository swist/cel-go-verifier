;; query 1 verifyEquivalence
(assert (not ((_ is CelError) x)))
(assert (not ((_ is CelUnknown) x)))
(assert (let ((a!1 (not (or (> (getInt x) 9223372036854775807)                     (< (getInt x) (- 9223372036854775808))))))   (or ((_ is CelError) x) ((_ is CelUnknown) x) (and ((_ is Int) x) a!1))))
(push)
(assert (let ((a!1 (Bool (> (getInt x) (getInt (Int 10)))))       (a!2 (ite (or ((_ is CelUnknown) x))                 (CelUnknown (_>_ x (Int 10)))                 CelError))) (let ((a!3 (ite (and ((_ is Int) x) ((_ is Int) (Int 10))) a!1 a!2))) (let ((a!4 (ite (or ((_ is CelError) x) ((_ is CelError) (Int 10)))                 CelError                 a!3))) (let ((a!5 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) (Int 10)))                 (CelUnknown (_>_ x (Int 10)))                 a!4)))   (not (= a!5 a!5)))))))
(assert (let ((a!1 (ite (and ((_ is Int) x) ((_ is Int) (Int 10))) false false))       (a!2 (Bool (> (getInt x) (getInt (Int 10)))))       (a!3 (ite (or ((_ is CelUnknown) x))                 (CelUnknown (_>_ x (Int 10)))                 CelError))) (let ((a!4 (ite (and ((_ is Int) x) ((_ is Int) (Int 10))) a!2 a!3))) (let ((a!5 (ite (or ((_ is CelError) x) ((_ is CelError) (Int 10)))                 CelError                 a!4))) (let ((a!6 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) (Int 10)))                 (CelUnknown (_>_ x (Int 10)))                 a!5)))   (not (or a!1 a!1 (and ((_ is CelUnknown) a!6) ((_ is CelUnknown) a!6)))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (Bool (> (getInt x) (getInt (Int 10)))))       (a!2 (ite (or ((_ is CelUnknown) x))                 (CelUnknown (_>_ x (Int 10)))                 CelError))) (let ((a!3 (ite (and ((_ is Int) x) ((_ is Int) (Int 10))) a!1 a!2))) (let ((a!4 (ite (or ((_ is CelError) x) ((_ is CelError) (Int 10)))                 CelError                 a!3))) (let ((a!5 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) (Int 10)))                 (CelUnknown (_>_ x (Int 10)))                 a!4)))   (not (= a!5 a!5)))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
