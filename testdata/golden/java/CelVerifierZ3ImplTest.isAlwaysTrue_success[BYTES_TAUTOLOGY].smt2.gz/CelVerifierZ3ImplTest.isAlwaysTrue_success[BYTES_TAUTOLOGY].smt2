;; query 1 isAlwaysTrue
(assert (not ((_ is CelError) by)))
(assert (not ((_ is CelUnknown) by)))
(assert (or ((_ is CelError) by) ((_ is CelUnknown) by) ((_ is Bytes) by)))
(assert (let ((a!1 (= (!mkListRef (as_seq (getListRef by))) (getListRef by))))   (=> ((_ is List) by) a!1)))
(assert (let ((a!1 (= (!mkMapRef (map_values (getMapRef by))                          (map_presence (getMapRef by)))               (getMapRef by))))   (=> ((_ is Map) by) a!1)))
(assert (let ((a!1 (= (!mkMsgRef (msg_type_name (getMessageRef by))                          (msg_values (getMessageRef by))                          (msg_presence (getMessageRef by)))               (getMessageRef by))))   (=> ((_ is Message) by) a!1)))
(push)
(assert (let ((a!1 (and (= (map_presence (getMapRef by)) (map_presence (getMapRef by)))                 (= (map_values (getMapRef by)) (map_values (getMapRef by)))))       (a!2 (and (= (msg_type_name (getMessageRef by))                    (msg_type_name (getMessageRef by)))                 (= (msg_values (getMessageRef by))                    (msg_values (getMessageRef by)))                 (= (msg_presence (getMessageRef by))                    (msg_presence (getMessageRef by)))))) (let ((a!3 (ite (and ((_ is Message) by) ((_ is Message) by))                 a!2                 (ite (and ((_ is Double) by) ((_ is Double) by))                      (fp.eq (getDouble by) (getDouble by))                      (= by by))))) (let ((a!4 (ite (and ((_ is List) by) ((_ is List) by))                 (= (as_seq (getListRef by)) (as_seq (getListRef by)))                 (ite (and ((_ is Map) by) ((_ is Map) by)) a!1 a!3)))) (let ((a!5 (ite (or ((_ is CelUnknown) by) ((_ is CelUnknown) by))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) by) ((_ is CelError) by))                      CelError                      (Bool a!4)))))   (not (and ((_ is Bool) a!5) (getBool a!5))))))))
(assert (not false))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (and (= (map_presence (getMapRef by)) (map_presence (getMapRef by)))                 (= (map_values (getMapRef by)) (map_values (getMapRef by)))))       (a!2 (and (= (msg_type_name (getMessageRef by))                    (msg_type_name (getMessageRef by)))                 (= (msg_values (getMessageRef by))                    (msg_values (getMessageRef by)))                 (= (msg_presence (getMessageRef by))                    (msg_presence (getMessageRef by)))))) (let ((a!3 (ite (and ((_ is Message) by) ((_ is Message) by))                 a!2                 (ite (and ((_ is Double) by) ((_ is Double) by))                      (fp.eq (getDouble by) (getDouble by))                      (= by by))))) (let ((a!4 (ite (and ((_ is List) by) ((_ is List) by))                 (= (as_seq (getListRef by)) (as_seq (getListRef by)))                 (ite (and ((_ is Map) by) ((_ is Map) by)) a!1 a!3)))) (let ((a!5 (ite (or ((_ is CelUnknown) by) ((_ is CelUnknown) by))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) by) ((_ is CelError) by))                      CelError                      (Bool a!4)))))   (not (and ((_ is Bool) a!5) (getBool a!5))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
