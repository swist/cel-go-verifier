;; query 1 isAlwaysTrue
(assert (= (as_seq !listRef_!0) (as seq.empty (Seq CelValue))))
(assert (= (!mkListRef (as_seq !listRef_!0)) !listRef_!0))
(assert (let ((a!1 (!mkListRef (as_seq (getListRef (List !listRef_!0))))))   (=> ((_ is List) (List !listRef_!0)) (= a!1 (getListRef (List !listRef_!0))))))
(push)
(assert (let ((a!1 (seq.len (as_seq (getListRef (List !listRef_!0)))))) (let ((a!2 (ite (or ((_ is CelError) (List !listRef_!0))                     ((_ is CelError) (List !listRef_!0)))                 CelError                 (Bool (= a!1 a!1))))) (let ((a!3 (ite (or ((_ is CelUnknown) (List !listRef_!0))                     ((_ is CelUnknown) (List !listRef_!0)))                 (CelUnknown !generic_unknown)                 a!2)))   (not (and ((_ is Bool) a!3) (getBool a!3)))))))
(assert (not false))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (seq.len (as_seq (getListRef (List !listRef_!0)))))) (let ((a!2 (ite (or ((_ is CelError) (List !listRef_!0))                     ((_ is CelError) (List !listRef_!0)))                 CelError                 (Bool (= a!1 a!1))))) (let ((a!3 (ite (or ((_ is CelUnknown) (List !listRef_!0))                     ((_ is CelUnknown) (List !listRef_!0)))                 (CelUnknown !generic_unknown)                 a!2)))   (not (and ((_ is Bool) a!3) (getBool a!3)))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
