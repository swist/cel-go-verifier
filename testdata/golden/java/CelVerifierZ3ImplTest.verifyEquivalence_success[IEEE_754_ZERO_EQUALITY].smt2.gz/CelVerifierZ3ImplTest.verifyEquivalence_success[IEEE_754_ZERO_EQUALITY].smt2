;; query 1 verifyEquivalence
(push)
(assert (let ((a!1 (Bool (fp.eq (getDouble (Double (_ +zero 11 53))) (_ -zero 11 53)))))   (not (= a!1 (Bool true)))))
(assert (let ((a!1 (Bool (fp.eq (getDouble (Double (_ +zero 11 53))) (_ -zero 11 53)))))   (not (and ((_ is CelUnknown) a!1) ((_ is CelUnknown) (Bool true))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (Bool (fp.eq (getDouble (Double (_ +zero 11 53))) (_ -zero 11 53)))))   (not (= a!1 (Bool true)))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
