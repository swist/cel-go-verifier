;; query 1 isAlwaysTrue
(push)
(assert (let ((a!1 (and (>= (getInt (Int 1)) 0) (<= (getInt (Int 1)) 0)))) (let ((a!2 (and ((_ is Bool) (Bool (not a!1))) (getBool (Bool (not a!1))))))   (not a!2))))
(assert (not false))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (and (>= (getInt (Int 1)) 0) (<= (getInt (Int 1)) 0)))) (let ((a!2 (and ((_ is Bool) (Bool (not a!1))) (getBool (Bool (not a!1))))))   (not a!2))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
