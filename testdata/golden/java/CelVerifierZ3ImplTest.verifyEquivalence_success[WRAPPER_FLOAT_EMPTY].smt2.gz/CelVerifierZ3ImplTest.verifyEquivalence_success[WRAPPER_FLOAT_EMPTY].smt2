;; query 1 verifyEquivalence
(push)
(assert (let ((a!1 (ite (fp.isNaN (getDouble (Double (_ +zero 11 53))))                 (_ NaN 11 53)                 (getDouble (Double (_ +zero 11 53)))))       (a!4 ((_ to_fp 11 53)              roundNearestTiesToEven              ((_ to_fp 8 24)                roundNearestTiesToEven                (getDouble (Double (_ +zero 11 53))))))) (let ((a!2 (=> (fp.isNaN (getDouble (Double (_ +zero 11 53))))                (= (Double (_ +zero 11 53)) (Double a!1))))) (let ((a!3 (not (and ((_ is Double) (Double (_ +zero 11 53))) a!2)))) (let ((a!5 (ite a!3 CelError (Double (ite (fp.isNaN a!4) (_ NaN 11 53) a!4)))))   (not (= a!5 (Double (_ +zero 11 53)))))))))
(assert (let ((a!1 (ite (fp.isNaN (getDouble (Double (_ +zero 11 53))))                 (_ NaN 11 53)                 (getDouble (Double (_ +zero 11 53)))))       (a!4 ((_ to_fp 11 53)              roundNearestTiesToEven              ((_ to_fp 8 24)                roundNearestTiesToEven                (getDouble (Double (_ +zero 11 53))))))) (let ((a!2 (=> (fp.isNaN (getDouble (Double (_ +zero 11 53))))                (= (Double (_ +zero 11 53)) (Double a!1))))) (let ((a!3 (not (and ((_ is Double) (Double (_ +zero 11 53))) a!2)))) (let ((a!5 (ite a!3 CelError (Double (ite (fp.isNaN a!4) (_ NaN 11 53) a!4)))))   (not (and ((_ is CelUnknown) a!5)             ((_ is CelUnknown) (Double (_ +zero 11 53))))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (fp.isNaN (getDouble (Double (_ +zero 11 53))))                 (_ NaN 11 53)                 (getDouble (Double (_ +zero 11 53)))))       (a!4 ((_ to_fp 11 53)              roundNearestTiesToEven              ((_ to_fp 8 24)                roundNearestTiesToEven                (getDouble (Double (_ +zero 11 53))))))) (let ((a!2 (=> (fp.isNaN (getDouble (Double (_ +zero 11 53))))                (= (Double (_ +zero 11 53)) (Double a!1))))) (let ((a!3 (not (and ((_ is Double) (Double (_ +zero 11 53))) a!2)))) (let ((a!5 (ite a!3 CelError (Double (ite (fp.isNaN a!4) (_ NaN 11 53) a!4)))))   (not (= a!5 (Double (_ +zero 11 53)))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
