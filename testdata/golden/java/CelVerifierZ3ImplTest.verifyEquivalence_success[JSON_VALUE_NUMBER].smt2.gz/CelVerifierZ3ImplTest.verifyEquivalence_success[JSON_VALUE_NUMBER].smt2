;; query 1 verifyEquivalence
(push)
(assert (not (= (Double (fp #b0 #b01111111111 #x0000000000000))         (Double (fp #b0 #b01111111111 #x0000000000000)))))
(assert (not (and ((_ is CelUnknown) (Double (fp #b0 #b01111111111 #x0000000000000)))           ((_ is CelUnknown) (Double (fp #b0 #b01111111111 #x0000000000000))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (not (= (Double (fp #b0 #b01111111111 #x0000000000000))         (Double (fp #b0 #b01111111111 #x0000000000000)))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
