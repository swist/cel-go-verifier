;; query 1 isSatisfiable
(assert (not ((_ is CelError) string_var)))
(assert (not ((_ is CelUnknown) string_var)))
(assert (or ((_ is CelError) string_var)     ((_ is CelUnknown) string_var)     ((_ is String) string_var)))
(assert (or ((_ is Int) (string_to_int64 string_var))     ((_ is CelError) (string_to_int64 string_var))))
(assert (let ((a!1 (or (> (getInt (string_to_int64 string_var)) 9223372036854775807)                (< (getInt (string_to_int64 string_var)) (- 9223372036854775808)))))   (=> ((_ is Int) (string_to_int64 string_var)) (not a!1))))
(assert !approx!0)
(push)
(assert (let ((a!1 (ite ((_ is String) string_var)                 (string_to_int64 string_var)                 (ite (or ((_ is CelUnknown) string_var))                      (CelUnknown !generic_unknown)                      CelError)))) (let ((a!2 (ite (or ((_ is CelUnknown) string_var))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) string_var)) CelError a!1)))) (let ((a!3 (Bool (and (>= (getInt a!2) 5) (<= (getInt a!2) 5))))) (let ((a!4 (ite (or ((_ is CelUnknown) a!2))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) a!2)) CelError a!3))))   (and ((_ is Bool) a!4) (getBool a!4)))))))
(assert (let ((a!1 (ite ((_ is String) string_var)                 (string_to_int64 string_var)                 (ite (or ((_ is CelUnknown) string_var))                      (CelUnknown !generic_unknown)                      CelError)))) (let ((a!2 (ite (or ((_ is CelUnknown) string_var))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) string_var)) CelError a!1)))) (let ((a!3 (and ((_ is CelUnknown) a!2)                 (not (ite ((_ is String) string_var) !approx!0 false))))       (a!4 (and ((_ is CelError) a!2)                 (not (ite ((_ is String) string_var) !approx!0 false))                 (not ((_ is CelUnknown) a!2))))) (let ((a!5 (or a!3 a!4 (not (ite ((_ is String) string_var) !approx!0 false)))))   (not (not a!5)))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite ((_ is String) string_var)                 (string_to_int64 string_var)                 (ite (or ((_ is CelUnknown) string_var))                      (CelUnknown !generic_unknown)                      CelError)))) (let ((a!2 (ite (or ((_ is CelUnknown) string_var))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) string_var)) CelError a!1)))) (let ((a!3 (Bool (and (>= (getInt a!2) 5) (<= (getInt a!2) 5))))) (let ((a!4 (ite (or ((_ is CelUnknown) a!2))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) a!2)) CelError a!3))))   (and ((_ is Bool) a!4) (getBool a!4)))))))
(check-sat) ; SATISFIABLE
