;; query 1 isAlwaysTrue
(push)
(assert (let ((a!1 (not (fp.isNaN (getDouble (Double (fp #b0 #b01111111111 #x0000000000000))))))       (a!2 (not (fp.lt (fp #b0 #b10000000000 #x0000000000000)                        (getDouble (Double (fp #b0 #b01111111111 #x0000000000000))))))) (let ((a!3 (ite (and ((_ is Int) (Int 2))                      ((_ is Double)                        (Double (fp #b0 #b01111111111 #x0000000000000))))                 (Bool (and a!1 a!2))                 CelError))) (let ((a!4 (ite (or ((_ is CelError) (Int 2))                     ((_ is CelError)                       (Double (fp #b0 #b01111111111 #x0000000000000))))                 CelError                 a!3))) (let ((a!5 (ite (or ((_ is CelUnknown) (Int 2))                     ((_ is CelUnknown)                       (Double (fp #b0 #b01111111111 #x0000000000000))))                 (CelUnknown !generic_unknown)                 a!4)))   (not (and ((_ is Bool) a!5) (getBool a!5))))))))
(assert (let ((a!1 (ite (and ((_ is Int) (Int 2))                      ((_ is Double)                        (Double (fp #b0 #b01111111111 #x0000000000000))))                 false                 false)))   (not a!1)))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (not (fp.isNaN (getDouble (Double (fp #b0 #b01111111111 #x0000000000000))))))       (a!2 (not (fp.lt (fp #b0 #b10000000000 #x0000000000000)                        (getDouble (Double (fp #b0 #b01111111111 #x0000000000000))))))) (let ((a!3 (ite (and ((_ is Int) (Int 2))                      ((_ is Double)                        (Double (fp #b0 #b01111111111 #x0000000000000))))                 (Bool (and a!1 a!2))                 CelError))) (let ((a!4 (ite (or ((_ is CelError) (Int 2))                     ((_ is CelError)                       (Double (fp #b0 #b01111111111 #x0000000000000))))                 CelError                 a!3))) (let ((a!5 (ite (or ((_ is CelUnknown) (Int 2))                     ((_ is CelUnknown)                       (Double (fp #b0 #b01111111111 #x0000000000000))))                 (CelUnknown !generic_unknown)                 a!4)))   (not (and ((_ is Bool) a!5) (getBool a!5))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
