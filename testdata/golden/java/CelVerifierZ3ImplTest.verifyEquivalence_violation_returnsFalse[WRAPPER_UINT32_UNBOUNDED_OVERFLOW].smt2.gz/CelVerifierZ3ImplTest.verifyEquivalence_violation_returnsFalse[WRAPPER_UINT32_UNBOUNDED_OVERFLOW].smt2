;; query 1 verifyEquivalence
(assert (not ((_ is CelError) u)))
(assert (not ((_ is CelUnknown) u)))
(assert (let ((a!1 (not (or (> (getUint u) 18446744073709551615) (< (getUint u) 0)))))   (or ((_ is CelError) u) ((_ is CelUnknown) u) (and ((_ is Uint) u) a!1))))
(push)
(assert (let ((a!1 (not (or (> (getUint u) 18446744073709551615) (< (getUint u) 0))))) (let ((a!2 (not (and ((_ is Uint) u)                      a!1                      (>= (getUint u) 0)                      (<= (getUint u) 4294967295))))) (let ((a!3 (ite (or ((_ is CelUnknown) u))                 (CelUnknown (|struct_google.protobuf.UInt32Value_value:false| u))                 (ite (or ((_ is CelError) u)) CelError (ite a!2 CelError u)))))   (not (= a!3 u))))))
(assert (let ((a!1 (not (or (> (getUint u) 18446744073709551615) (< (getUint u) 0))))) (let ((a!2 (not (and ((_ is Uint) u)                      a!1                      (>= (getUint u) 0)                      (<= (getUint u) 4294967295))))) (let ((a!3 (ite (or ((_ is CelUnknown) u))                 (CelUnknown (|struct_google.protobuf.UInt32Value_value:false| u))                 (ite (or ((_ is CelError) u)) CelError (ite a!2 CelError u)))))   (not (and ((_ is CelUnknown) a!3) ((_ is CelUnknown) u)))))))
(check-sat) ; SATISFIABLE
