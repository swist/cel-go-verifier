;; query 1 isSatisfiable
(assert (not ((_ is CelError) role)))
(assert (not ((_ is CelUnknown) role)))
(assert (or ((_ is CelError) role) ((_ is CelUnknown) role) ((_ is String) role)))
(push)
(assert (let ((a!1 (Bool (str.<= (getString role) (getString (String "admin")))))) (let ((a!2 (ite (and ((_ is String) role) ((_ is String) (String "admin")))                 a!1                 (ite (or ((_ is CelUnknown) role))                      (CelUnknown !generic_unknown)                      CelError)))) (let ((a!3 (ite (or ((_ is CelError) role) ((_ is CelError) (String "admin")))                 CelError                 a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) role)                     ((_ is CelUnknown) (String "admin")))                 (CelUnknown !generic_unknown)                 a!3)))   (and ((_ is Bool) a!4) (getBool a!4)))))))
(assert (let ((a!1 (ite (and ((_ is String) role) ((_ is String) (String "admin")))                 false                 false)))   (not a!1)))
(check-sat) ; SATISFIABLE
