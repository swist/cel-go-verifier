;; query 1 isAlwaysTrue
(push)
(assert (let ((a!1 (> (* (getUint (Uint 0)) (getUint (Uint 0))) 18446744073709551615))       (a!2 (< (* (getUint (Uint 0)) (getUint (Uint 0))) 0))       (a!3 (Uint (* (getUint (Uint 0)) (getUint (Uint 0)))))) (let ((a!4 (ite (and ((_ is Uint) (Uint 0)) ((_ is Uint) (Uint 0)))                 (ite (or a!1 a!2) CelError a!3)                 CelError))) (let ((a!5 (ite (or ((_ is CelError) (Uint 0)) ((_ is CelError) (Uint 0)))                 CelError                 a!4))) (let ((a!6 (ite (or ((_ is CelUnknown) (Uint 0)) ((_ is CelUnknown) (Uint 0)))                 (CelUnknown !generic_unknown)                 a!5))) (let ((a!7 (Bool (and (>= (getUint a!6) 0) (<= (getUint a!6) 0))))) (let ((a!8 (ite (or ((_ is CelUnknown) a!6))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) a!6)) CelError a!7))))   (not (and ((_ is Bool) a!8) (getBool a!8))))))))))
(assert (let ((a!1 (> (* (getUint (Uint 0)) (getUint (Uint 0))) 18446744073709551615))       (a!2 (< (* (getUint (Uint 0)) (getUint (Uint 0))) 0))       (a!3 (Uint (* (getUint (Uint 0)) (getUint (Uint 0)))))       (a!7 (ite (and ((_ is Uint) (Uint 0)) ((_ is Uint) (Uint 0))) false false))) (let ((a!4 (ite (and ((_ is Uint) (Uint 0)) ((_ is Uint) (Uint 0)))                 (ite (or a!1 a!2) CelError a!3)                 CelError))) (let ((a!5 (ite (or ((_ is CelError) (Uint 0)) ((_ is CelError) (Uint 0)))                 CelError                 a!4))) (let ((a!6 (ite (or ((_ is CelUnknown) (Uint 0)) ((_ is CelUnknown) (Uint 0)))                 (CelUnknown !generic_unknown)                 a!5))) (let ((a!8 (or (and ((_ is CelUnknown) a!6) (not a!7))                (and ((_ is CelError) a!6)                     (not a!7)                     (not ((_ is CelUnknown) a!6)))                (not a!7))))   (not (not a!8))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (> (* (getUint (Uint 0)) (getUint (Uint 0))) 18446744073709551615))       (a!2 (< (* (getUint (Uint 0)) (getUint (Uint 0))) 0))       (a!3 (Uint (* (getUint (Uint 0)) (getUint (Uint 0)))))) (let ((a!4 (ite (and ((_ is Uint) (Uint 0)) ((_ is Uint) (Uint 0)))                 (ite (or a!1 a!2) CelError a!3)                 CelError))) (let ((a!5 (ite (or ((_ is CelError) (Uint 0)) ((_ is CelError) (Uint 0)))                 CelError                 a!4))) (let ((a!6 (ite (or ((_ is CelUnknown) (Uint 0)) ((_ is CelUnknown) (Uint 0)))                 (CelUnknown !generic_unknown)                 a!5))) (let ((a!7 (Bool (and (>= (getUint a!6) 0) (<= (getUint a!6) 0))))) (let ((a!8 (ite (or ((_ is CelUnknown) a!6))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) a!6)) CelError a!7))))   (not (and ((_ is Bool) a!8) (getBool a!8))))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
