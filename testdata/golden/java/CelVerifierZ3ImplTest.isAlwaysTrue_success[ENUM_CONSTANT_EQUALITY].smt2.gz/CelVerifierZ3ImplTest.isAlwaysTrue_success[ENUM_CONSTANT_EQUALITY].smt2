;; query 1 isAlwaysTrue
(push)
(assert (let ((a!1 (and (>= (getInt (Int 1)) 1) (<= (getInt (Int 1)) 1))))   (not (and ((_ is Bool) (Bool a!1)) (getBool (Bool a!1))))))
(assert (not false))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (and (>= (getInt (Int 1)) 1) (<= (getInt (Int 1)) 1))))   (not (and ((_ is Bool) (Bool a!1)) (getBool (Bool a!1))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
