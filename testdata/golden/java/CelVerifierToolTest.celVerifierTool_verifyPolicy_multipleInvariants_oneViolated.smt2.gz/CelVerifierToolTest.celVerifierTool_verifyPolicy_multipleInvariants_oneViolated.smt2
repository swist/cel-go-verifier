;; query 1 verifyImplication
(assert (not ((_ is CelError) port)))
(assert (not ((_ is CelUnknown) port)))
(assert (let ((a!1 (not (or (> (getInt port) 9223372036854775807)                     (< (getInt port) (- 9223372036854775808))))))   (or ((_ is CelError) port)       ((_ is CelUnknown) port)       (and ((_ is Int) port) a!1))))
(push)
(assert (let ((a!1 (Bool (and (>= (getInt port) 80) (<= (getInt port) 80))))       (a!3 (not (and (>= (getInt port) 80) (<= (getInt port) 80))))) (let ((a!2 (ite (or ((_ is CelUnknown) port))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) port)) CelError a!1)))       (a!4 (ite (or ((_ is CelUnknown) port))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) port)) CelError (Bool a!3))))) (let ((a!5 (or (not (or ((_ is Bool) a!2) ((_ is CelUnknown) a!2)))                (not (or ((_ is Bool) a!4) ((_ is CelUnknown) a!4)))))) (let ((a!6 (ite (or (and ((_ is Bool) a!2) (getBool a!2))                     (and ((_ is Bool) a!4) (getBool a!4)))                 (Bool true)                 (ite (or ((_ is CelUnknown) a!2) ((_ is CelUnknown) a!4))                      (ite ((_ is CelUnknown) a!2) a!2 a!4)                      (ite a!5 CelError (Bool false))))))   (and ((_ is Bool) (Bool true))        (getBool (Bool true))        (not (and ((_ is Bool) a!6) (getBool a!6)))))))))
(assert (not false))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (Bool (and (>= (getInt port) 80) (<= (getInt port) 80))))       (a!3 (not (and (>= (getInt port) 80) (<= (getInt port) 80))))) (let ((a!2 (ite (or ((_ is CelUnknown) port))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) port)) CelError a!1)))       (a!4 (ite (or ((_ is CelUnknown) port))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) port)) CelError (Bool a!3))))) (let ((a!5 (or (not (or ((_ is Bool) a!2) ((_ is CelUnknown) a!2)))                (not (or ((_ is Bool) a!4) ((_ is CelUnknown) a!4)))))) (let ((a!6 (ite (or (and ((_ is Bool) a!2) (getBool a!2))                     (and ((_ is Bool) a!4) (getBool a!4)))                 (Bool true)                 (ite (or ((_ is CelUnknown) a!2) ((_ is CelUnknown) a!4))                      (ite ((_ is CelUnknown) a!2) a!2 a!4)                      (ite a!5 CelError (Bool false))))))   (and ((_ is Bool) (Bool true))        (getBool (Bool true))        (not (and ((_ is Bool) a!6) (getBool a!6)))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (Bool (and (>= (getInt port) 80) (<= (getInt port) 80))))       (a!3 (not (and (>= (getInt port) 80) (<= (getInt port) 80))))) (let ((a!2 (ite (or ((_ is CelUnknown) port))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) port)) CelError a!1)))       (a!4 (ite (or ((_ is CelUnknown) port))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) port)) CelError (Bool a!3))))) (let ((a!5 (or (not (or ((_ is Bool) a!2) ((_ is CelUnknown) a!2)))                (not (or ((_ is Bool) a!4) ((_ is CelUnknown) a!4)))))) (let ((a!6 (ite (or (and ((_ is Bool) a!2) (getBool a!2))                     (and ((_ is Bool) a!4) (getBool a!4)))                 (Bool true)                 (ite (or ((_ is CelUnknown) a!2) ((_ is CelUnknown) a!4))                      (ite ((_ is CelUnknown) a!2) a!2 a!4)                      (ite a!5 CelError (Bool false))))))   (and ((_ is CelUnknown) (Bool true))        false        (not (and ((_ is Bool) a!6) (getBool a!6) (not false)))))))))
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
;; query 2 verifyImplication
(assert (not ((_ is CelError) port)))
(assert (not ((_ is CelUnknown) port)))
(assert (let ((a!1 (not (or (> (getInt port) 9223372036854775807)                     (< (getInt port) (- 9223372036854775808))))))   (or ((_ is CelError) port)       ((_ is CelUnknown) port)       (and ((_ is Int) port) a!1))))
(push)
(assert (let ((a!1 (Bool (> (getInt port) (getInt (Int 1024)))))) (let ((a!2 (ite (and ((_ is Int) port) ((_ is Int) (Int 1024)))                 a!1                 (ite (or ((_ is CelUnknown) port))                      (CelUnknown !generic_unknown)                      CelError)))) (let ((a!3 (ite (or ((_ is CelError) port) ((_ is CelError) (Int 1024)))                 CelError                 a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) port) ((_ is CelUnknown) (Int 1024)))                 (CelUnknown !generic_unknown)                 a!3)))   (and ((_ is Bool) (Bool true))        (getBool (Bool true))        (not (and ((_ is Bool) a!4) (getBool a!4)))))))))
(assert (let ((a!1 (ite (and ((_ is Int) port) ((_ is Int) (Int 1024))) false false)))   (not a!1)))
(check-sat) ; SATISFIABLE
