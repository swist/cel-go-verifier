;; query 1 isSatisfiable
(push)
(assert (let ((a!1 (and (>= (getInt (Int 1)) 0) (<= (getInt (Int 1)) 0))))   (and ((_ is Bool) (Bool a!1)) (getBool (Bool a!1)))))
(assert (not false))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (and (>= (getInt (Int 1)) 0) (<= (getInt (Int 1)) 0))))   (and ((_ is Bool) (Bool a!1)) (getBool (Bool a!1)))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (and (>= (getInt (Int 1)) 0) (<= (getInt (Int 1)) 0))))   (and ((_ is CelUnknown) (Bool a!1)) false)))
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
