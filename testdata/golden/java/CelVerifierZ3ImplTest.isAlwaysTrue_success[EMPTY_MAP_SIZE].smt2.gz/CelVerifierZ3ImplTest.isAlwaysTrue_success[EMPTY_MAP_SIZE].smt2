;; query 1 isAlwaysTrue
(assert (= (map_values !mapRef_!0)    ((as const (Array CelValue CelValue)) (CelUnknown !generic_unknown))))
(assert (= (map_presence !mapRef_!0) ((as const (Array CelValue Bool)) false)))
(assert (= (map_keys !mapRef_!0) (as seq.empty (Seq CelValue))))
(assert (let ((a!1 (map_keys (getMapRef (ite false CelError (Map !mapRef_!0))))))   (<= (seq.len a!1) 2147483647)))
(assert (= (!mkMapRef (map_values !mapRef_!0) (map_presence !mapRef_!0)) !mapRef_!0))
(assert (let ((a!1 (map_values (getMapRef (ite false CelError (Map !mapRef_!0)))))       (a!2 (map_presence (getMapRef (ite false CelError (Map !mapRef_!0)))))) (let ((a!3 (= (!mkMapRef a!1 a!2)               (getMapRef (ite false CelError (Map !mapRef_!0))))))   (=> ((_ is Map) (ite false CelError (Map !mapRef_!0))) a!3))))
(push)
(assert (let ((a!1 (or ((_ is CelUnknown) (ite false CelError (Map !mapRef_!0)))))       (a!2 (or ((_ is CelError) (ite false CelError (Map !mapRef_!0)))))       (a!3 (map_keys (getMapRef (ite false CelError (Map !mapRef_!0)))))) (let ((a!4 (ite ((_ is Map) (ite false CelError (Map !mapRef_!0)))                 (Int (seq.len a!3))                 (ite a!1 (CelUnknown !generic_unknown) CelError)))) (let ((a!5 (or ((_ is CelUnknown)                  (ite a!1 (CelUnknown !generic_unknown) (ite a!2 CelError a!4)))))       (a!6 (or ((_ is CelError)                  (ite a!1 (CelUnknown !generic_unknown) (ite a!2 CelError a!4)))))       (a!7 (>= (getInt (ite a!1                             (CelUnknown !generic_unknown)                             (ite a!2 CelError a!4)))                0))       (a!8 (<= (getInt (ite a!1                             (CelUnknown !generic_unknown)                             (ite a!2 CelError a!4)))                0))) (let ((a!9 (ite a!5                 (CelUnknown !generic_unknown)                 (ite a!6 CelError (Bool (and a!7 a!8))))))   (not (and ((_ is Bool) a!9) (getBool a!9))))))))
(assert (let ((a!1 (or ((_ is CelUnknown) (ite false CelError (Map !mapRef_!0)))))       (a!2 (or ((_ is CelError) (ite false CelError (Map !mapRef_!0)))))       (a!3 (map_keys (getMapRef (ite false CelError (Map !mapRef_!0)))))       (a!5 (ite ((_ is Map) (ite false CelError (Map !mapRef_!0))) false false))) (let ((a!4 (ite ((_ is Map) (ite false CelError (Map !mapRef_!0)))                 (Int (seq.len a!3))                 (ite a!1 (CelUnknown !generic_unknown) CelError)))) (let ((a!6 (and ((_ is CelUnknown)                   (ite a!1 (CelUnknown !generic_unknown) (ite a!2 CelError a!4)))                 (not a!5)))       (a!7 (not ((_ is CelUnknown)                   (ite a!1 (CelUnknown !generic_unknown) (ite a!2 CelError a!4)))))) (let ((a!8 (and ((_ is CelError)                   (ite a!1 (CelUnknown !generic_unknown) (ite a!2 CelError a!4)))                 (not a!5)                 a!7)))   (not (not (or a!6 a!8 (not a!5)))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (or ((_ is CelUnknown) (ite false CelError (Map !mapRef_!0)))))       (a!2 (or ((_ is CelError) (ite false CelError (Map !mapRef_!0)))))       (a!3 (map_keys (getMapRef (ite false CelError (Map !mapRef_!0)))))) (let ((a!4 (ite ((_ is Map) (ite false CelError (Map !mapRef_!0)))                 (Int (seq.len a!3))                 (ite a!1 (CelUnknown !generic_unknown) CelError)))) (let ((a!5 (or ((_ is CelUnknown)                  (ite a!1 (CelUnknown !generic_unknown) (ite a!2 CelError a!4)))))       (a!6 (or ((_ is CelError)                  (ite a!1 (CelUnknown !generic_unknown) (ite a!2 CelError a!4)))))       (a!7 (>= (getInt (ite a!1                             (CelUnknown !generic_unknown)                             (ite a!2 CelError a!4)))                0))       (a!8 (<= (getInt (ite a!1                             (CelUnknown !generic_unknown)                             (ite a!2 CelError a!4)))                0))) (let ((a!9 (ite a!5                 (CelUnknown !generic_unknown)                 (ite a!6 CelError (Bool (and a!7 a!8))))))   (not (and ((_ is Bool) a!9) (getBool a!9))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
