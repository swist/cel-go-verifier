;; query 1 isAlwaysTrue
(assert (let ((a!1 (> (getInt (!fn_dummy_add_overload (Int 1) (Int 1)))               9223372036854775807))       (a!2 (< (getInt (!fn_dummy_add_overload (Int 1) (Int 1)))               (- 9223372036854775808)))) (let ((a!3 (and ((_ is Int) (!fn_dummy_add_overload (Int 1) (Int 1)))                 (not (or a!1 a!2)))))   (or ((_ is CelError) (!fn_dummy_add_overload (Int 1) (Int 1)))       ((_ is CelUnknown) (!fn_dummy_add_overload (Int 1) (Int 1)))       a!3))))
(assert (not ((_ is CelUnknown) (!fn_dummy_add_overload (Int 1) (Int 1)))))
(assert (not ((_ is CelError) (!fn_dummy_add_overload (Int 1) (Int 1)))))
(assert !approx!0)
(push)
(assert (let ((a!1 (or ((_ is CelUnknown) (!fn_dummy_add_overload (Int 1) (Int 1)))))       (a!2 (or ((_ is CelError) (!fn_dummy_add_overload (Int 1) (Int 1)))))       (a!3 (>= (getInt (!fn_dummy_add_overload (Int 1) (Int 1))) 2))       (a!4 (<= (getInt (!fn_dummy_add_overload (Int 1) (Int 1))) 2))) (let ((a!5 (ite a!1                 (CelUnknown !generic_unknown)                 (ite a!2 CelError (Bool (and a!3 a!4))))))   (not (and ((_ is Bool) a!5) (getBool a!5))))))
(assert (let ((a!1 (and ((_ is CelUnknown) (!fn_dummy_add_overload (Int 1) (Int 1)))                 (not !approx!0)))       (a!2 (not ((_ is CelUnknown) (!fn_dummy_add_overload (Int 1) (Int 1)))))) (let ((a!3 (and ((_ is CelError) (!fn_dummy_add_overload (Int 1) (Int 1)))                 (not !approx!0)                 a!2)))   (not (not (or a!1 a!3 (not !approx!0)))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (or ((_ is CelUnknown) (!fn_dummy_add_overload (Int 1) (Int 1)))))       (a!2 (or ((_ is CelError) (!fn_dummy_add_overload (Int 1) (Int 1)))))       (a!3 (>= (getInt (!fn_dummy_add_overload (Int 1) (Int 1))) 2))       (a!4 (<= (getInt (!fn_dummy_add_overload (Int 1) (Int 1))) 2))) (let ((a!5 (ite a!1                 (CelUnknown !generic_unknown)                 (ite a!2 CelError (Bool (and a!3 a!4))))))   (not (and ((_ is Bool) a!5) (getBool a!5))))))
(check-sat) ; SATISFIABLE
