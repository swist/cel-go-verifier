;; query 1 verifyEquivalence
(assert (= (as_seq !listRef_!0)    (seq.++ (as seq.empty (Seq CelValue))            (seq.unit (String "tag1"))            (seq.unit (String "tag2")))))
(assert (=> (!has_truncated_type_constraint (String "tag1"))     (or ((_ is CelError) (List !listRef_!0))         ((_ is CelUnknown) (List !listRef_!0))         (!has_truncated_type_constraint (List !listRef_!0)))))
(assert (=> (!has_truncated_type_constraint (String "tag2"))     (or ((_ is CelError) (List !listRef_!0))         ((_ is CelUnknown) (List !listRef_!0))         (!has_truncated_type_constraint (List !listRef_!0)))))
(assert (= (as_seq !listRef_!1)    (seq.++ (as seq.empty (Seq CelValue)) (seq.unit (List !listRef_!0)))))
(assert (=> (!has_truncated_type_constraint (List !listRef_!0))     (or ((_ is CelError) (List !listRef_!1))         ((_ is CelUnknown) (List !listRef_!1))         (!has_truncated_type_constraint (List !listRef_!1)))))
(assert (= (!mkListRef (as_seq !listRef_!0)) !listRef_!0))
(assert (= (!mkListRef (as_seq !listRef_!1)) !listRef_!1))
(push)
(assert (let ((a!1 (ite (or ((_ is CelError) (List !listRef_!0)))                 CelError                 (List !listRef_!1)))) (let ((a!2 (ite (or ((_ is CelUnknown) (List !listRef_!0)))                 (CelUnknown (|LIST_[]| (List !listRef_!0)))                 a!1)))   (not (= a!2 a!2)))))
(assert (let ((a!1 (ite (or ((_ is CelError) (List !listRef_!0)))                 CelError                 (List !listRef_!1)))) (let ((a!2 (ite (or ((_ is CelUnknown) (List !listRef_!0)))                 (CelUnknown (|LIST_[]| (List !listRef_!0)))                 a!1)))   (not (and ((_ is CelUnknown) a!2) ((_ is CelUnknown) a!2))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (or ((_ is CelError) (List !listRef_!0)))                 CelError                 (List !listRef_!1)))) (let ((a!2 (ite (or ((_ is CelUnknown) (List !listRef_!0)))                 (CelUnknown (|LIST_[]| (List !listRef_!0)))                 a!1)))   (not (= a!2 a!2)))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
