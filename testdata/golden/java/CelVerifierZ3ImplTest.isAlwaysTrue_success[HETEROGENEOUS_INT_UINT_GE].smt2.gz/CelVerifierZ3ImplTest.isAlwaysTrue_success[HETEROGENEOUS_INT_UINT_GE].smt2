;; query 1 isAlwaysTrue
(push)
(assert (let ((a!1 (Bool (>= (getInt (Int 2)) (getUint (Uint 1)))))) (let ((a!2 (ite (and ((_ is Int) (Int 2)) ((_ is Uint) (Uint 1))) a!1 CelError))) (let ((a!3 (ite (or ((_ is CelError) (Int 2)) ((_ is CelError) (Uint 1)))                 CelError                 a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) (Int 2)) ((_ is CelUnknown) (Uint 1)))                 (CelUnknown !generic_unknown)                 a!3)))   (not (and ((_ is Bool) a!4) (getBool a!4))))))))
(assert (let ((a!1 (ite (and ((_ is Int) (Int 2)) ((_ is Uint) (Uint 1))) false false)))   (not a!1)))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (Bool (>= (getInt (Int 2)) (getUint (Uint 1)))))) (let ((a!2 (ite (and ((_ is Int) (Int 2)) ((_ is Uint) (Uint 1))) a!1 CelError))) (let ((a!3 (ite (or ((_ is CelError) (Int 2)) ((_ is CelError) (Uint 1)))                 CelError                 a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) (Int 2)) ((_ is CelUnknown) (Uint 1)))                 (CelUnknown !generic_unknown)                 a!3)))   (not (and ((_ is Bool) a!4) (getBool a!4))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
