;; query 1 verifyEquivalence
(assert (not ((_ is CelError) int_list)))
(assert (not ((_ is CelUnknown) int_list)))
(assert (let ((a!1 (> (seq.len (as_seq (getListRef int_list))) 0)))   (or ((_ is CelError) int_list)       ((_ is CelUnknown) int_list)       (and ((_ is List) int_list)            (=> a!1 (!has_truncated_type_constraint int_list))))))
(assert (let ((a!1 (= (!mkListRef (as_seq (getListRef int_list))) (getListRef int_list))))   (=> ((_ is List) int_list) a!1)))
(push)
(assert (let ((a!1 (> (seq.len (as_seq (getListRef int_list))) 0))) (let ((a!2 (ite (or false (and ((_ is List) int_list) a!1))                 (CelUnknown (!trunc_32098d73395a50fa int_list))                 (Bool true)))) (let ((a!3 (ite ((_ is CelError) int_list)                 CelError                 (ite ((_ is CelUnknown) int_list)                      (CelUnknown (!trunc_32098d73395a50fa int_list))                      a!2))))   (not (= a!3 a!3))))))
(assert (let ((a!1 (> (seq.len (as_seq (getListRef int_list))) 0))) (let ((a!2 (ite (or false (and ((_ is List) int_list) a!1))                 (or false (and ((_ is List) int_list) a!1) false)                 false))       (a!3 (ite (or false (and ((_ is List) int_list) a!1))                 (CelUnknown (!trunc_32098d73395a50fa int_list))                 (Bool true)))) (let ((a!4 (ite ((_ is CelError) int_list)                 CelError                 (ite ((_ is CelUnknown) int_list)                      (CelUnknown (!trunc_32098d73395a50fa int_list))                      a!3)))) (let ((a!5 (or (ite (or ((_ is CelError) int_list) ((_ is CelUnknown) int_list))                     false                     a!2)                (ite (or ((_ is CelError) int_list) ((_ is CelUnknown) int_list))                     false                     a!2)                (and ((_ is CelUnknown) a!4) ((_ is CelUnknown) a!4)))))   (not a!5))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (> (seq.len (as_seq (getListRef int_list))) 0))) (let ((a!2 (ite (or false (and ((_ is List) int_list) a!1))                 (CelUnknown (!trunc_32098d73395a50fa int_list))                 (Bool true)))) (let ((a!3 (ite ((_ is CelError) int_list)                 CelError                 (ite ((_ is CelUnknown) int_list)                      (CelUnknown (!trunc_32098d73395a50fa int_list))                      a!2))))   (not (= a!3 a!3))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert (let ((a!1 (> (seq.len (as_seq (getListRef int_list))) 0)))   (or (and ((_ is List) int_list) a!1) (and ((_ is List) int_list) a!1))))
(check-sat) ; UNSATISFIABLE
(pop)
