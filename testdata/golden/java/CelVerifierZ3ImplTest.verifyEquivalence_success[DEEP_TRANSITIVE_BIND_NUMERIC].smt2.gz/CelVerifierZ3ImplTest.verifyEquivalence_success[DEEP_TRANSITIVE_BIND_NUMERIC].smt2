;; query 1 verifyEquivalence
(push)
(assert (let ((a!1 (and (>= (getInt (Int 1)) 1) (<= (getInt (Int 1)) 1)))) (let ((a!2 (ite (or ((_ is CelError) (Int 1))) CelError (Bool a!1)))) (let ((a!3 (ite (or ((_ is CelUnknown) (Int 1)))                 (CelUnknown (_==_ (Int 1) (Int 1)))                 a!2)))   (not (= a!3 (Bool true)))))))
(assert (let ((a!1 (and (>= (getInt (Int 1)) 1) (<= (getInt (Int 1)) 1)))) (let ((a!2 (ite (or ((_ is CelError) (Int 1))) CelError (Bool a!1)))) (let ((a!3 (ite (or ((_ is CelUnknown) (Int 1)))                 (CelUnknown (_==_ (Int 1) (Int 1)))                 a!2)))   (not (and ((_ is CelUnknown) a!3) ((_ is CelUnknown) (Bool true))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (and (>= (getInt (Int 1)) 1) (<= (getInt (Int 1)) 1)))) (let ((a!2 (ite (or ((_ is CelError) (Int 1))) CelError (Bool a!1)))) (let ((a!3 (ite (or ((_ is CelUnknown) (Int 1)))                 (CelUnknown (_==_ (Int 1) (Int 1)))                 a!2)))   (not (= a!3 (Bool true)))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
