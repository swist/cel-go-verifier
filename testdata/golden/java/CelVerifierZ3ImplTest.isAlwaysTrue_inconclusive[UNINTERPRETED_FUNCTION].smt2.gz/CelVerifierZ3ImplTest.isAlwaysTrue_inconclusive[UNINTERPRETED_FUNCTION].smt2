;; query 1 isAlwaysTrue
(assert (not ((_ is CelError) request)))
(assert (not ((_ is CelUnknown) request)))
(assert (let ((a!1 (not (or (> (getInt request) 9223372036854775807)                     (< (getInt request) (- 9223372036854775808)))))       (a!2 (not (or (> (getUint request) 18446744073709551615)                     (< (getUint request) 0))))       (a!3 (Double (ite (fp.isNaN (getDouble request))                         (_ NaN 11 53)                         (getDouble request))))       (a!5 (not (or (> (getTimestamp request) 253402300799999999999)                     (< (getTimestamp request) (- 62135596800000000000)))))       (a!6 (not (or (> (getDuration request) 315576000000999999999)                     (< (getDuration request) (- 315576000000999999999)))))) (let ((a!4 (=> (and ((_ is Double) request) (fp.isNaN (getDouble request)))                (= request a!3))))   (or ((_ is CelError) request)       ((_ is CelUnknown) request)       (and (=> ((_ is Int) request) a!1)            (=> ((_ is Uint) request) a!2)            a!4            (=> ((_ is Timestamp) request) a!5)            (=> ((_ is Duration) request) a!6))))))
(assert (or ((_ is CelError) (!fn_matches_string request (String "^[a-z]+$")))     ((_ is CelUnknown) (!fn_matches_string request (String "^[a-z]+$")))     ((_ is Bool) (!fn_matches_string request (String "^[a-z]+$")))))
(assert (not ((_ is CelUnknown) (!fn_matches_string request (String "^[a-z]+$")))))
(assert (not ((_ is CelError) (!fn_matches_string request (String "^[a-z]+$")))))
(assert !approx!0)
(push)
(assert (let ((a!1 (ite (or ((_ is CelUnknown) request))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) request))                      CelError                      (!fn_matches_string request (String "^[a-z]+$"))))))   (not (and ((_ is Bool) a!1) (getBool a!1)))))
(assert (let ((a!1 (or ((_ is CelUnknown) request)                (and ((_ is CelError) request) (not ((_ is CelUnknown) request)))                (not !approx!0))))   (not (not a!1))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (or ((_ is CelUnknown) request))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) request))                      CelError                      (!fn_matches_string request (String "^[a-z]+$"))))))   (not (and ((_ is Bool) a!1) (getBool a!1)))))
(check-sat) ; SATISFIABLE
