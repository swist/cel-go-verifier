;; query 1 isAlwaysTrue
(push)
(assert (let ((a!1 (Bool (>= (getUint (Uint 2)) (getInt (Int 1)))))) (let ((a!2 (ite (and ((_ is Uint) (Uint 2)) ((_ is Int) (Int 1))) a!1 CelError))) (let ((a!3 (ite (or ((_ is CelError) (Uint 2)) ((_ is CelError) (Int 1)))                 CelError                 a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) (Uint 2)) ((_ is CelUnknown) (Int 1)))                 (CelUnknown !generic_unknown)                 a!3)))   (not (and ((_ is Bool) a!4) (getBool a!4))))))))
(assert (let ((a!1 (ite (and ((_ is Uint) (Uint 2)) ((_ is Int) (Int 1))) false false)))   (not a!1)))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (Bool (>= (getUint (Uint 2)) (getInt (Int 1)))))) (let ((a!2 (ite (and ((_ is Uint) (Uint 2)) ((_ is Int) (Int 1))) a!1 CelError))) (let ((a!3 (ite (or ((_ is CelError) (Uint 2)) ((_ is CelError) (Int 1)))                 CelError                 a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) (Uint 2)) ((_ is CelUnknown) (Int 1)))                 (CelUnknown !generic_unknown)                 a!3)))   (not (and ((_ is Bool) a!4) (getBool a!4))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
