;; query 1 verifyEquivalence
(assert (not ((_ is CelError) d)))
(assert (not ((_ is CelUnknown) d)))
(assert (let ((a!1 (Double (ite (fp.isNaN (getDouble d)) (_ NaN 11 53) (getDouble d))))) (let ((a!2 (and ((_ is Double) d) (=> (fp.isNaN (getDouble d)) (= d a!1)))))   (or ((_ is CelError) d) ((_ is CelUnknown) d) a!2))))
(push)
(assert (let ((a!1 (ite (fp.isNaN (fp.neg (getDouble d)))                 (_ NaN 11 53)                 (fp.neg (getDouble d))))) (let ((a!2 (ite (or ((_ is CelUnknown) d))                 (CelUnknown (-_ d))                 (ite (or ((_ is CelError) d)) CelError (Double a!1))))) (let ((a!3 (ite (or ((_ is CelUnknown) d))                 (CelUnknown (-_ d))                 (ite (or ((_ is CelError) d))                      CelError                      (ite ((_ is Double) d) (Double a!1) a!2))))) (let ((a!4 (ite (or ((_ is CelError) a!3))                 CelError                 (Bool (fp.eq (getDouble a!3)                              (fp #b0 #b10000000001 #x4000000000000)))))) (let ((a!5 (ite (or ((_ is CelUnknown) a!3))                 (CelUnknown (_==_ a!3                                   (Double (fp #b0 #b10000000001 #x4000000000000))))                 a!4)))   (not (= a!5 a!5))))))))
(assert (let ((a!1 (ite (fp.isNaN (fp.neg (getDouble d)))                 (_ NaN 11 53)                 (fp.neg (getDouble d))))) (let ((a!2 (ite (or ((_ is CelUnknown) d))                 (CelUnknown (-_ d))                 (ite (or ((_ is CelError) d)) CelError (Double a!1))))) (let ((a!3 (ite (or ((_ is CelUnknown) d))                 (CelUnknown (-_ d))                 (ite (or ((_ is CelError) d))                      CelError                      (ite ((_ is Double) d) (Double a!1) a!2))))) (let ((a!4 (and ((_ is CelUnknown) a!3)                 (not (ite ((_ is Double) d) false false))))       (a!5 (and ((_ is CelError) a!3)                 (not (ite ((_ is Double) d) false false))                 (not ((_ is CelUnknown) a!3))))       (a!7 (ite (or ((_ is CelError) a!3))                 CelError                 (Bool (fp.eq (getDouble a!3)                              (fp #b0 #b10000000001 #x4000000000000)))))) (let ((a!6 (or a!4 a!5 (not (ite ((_ is Double) d) false false))))       (a!8 (ite (or ((_ is CelUnknown) a!3))                 (CelUnknown (_==_ a!3                                   (Double (fp #b0 #b10000000001 #x4000000000000))))                 a!7)))   (not (or (not a!6)            (not a!6)            (and ((_ is CelUnknown) a!8) ((_ is CelUnknown) a!8))))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (fp.isNaN (fp.neg (getDouble d)))                 (_ NaN 11 53)                 (fp.neg (getDouble d))))) (let ((a!2 (ite (or ((_ is CelUnknown) d))                 (CelUnknown (-_ d))                 (ite (or ((_ is CelError) d)) CelError (Double a!1))))) (let ((a!3 (ite (or ((_ is CelUnknown) d))                 (CelUnknown (-_ d))                 (ite (or ((_ is CelError) d))                      CelError                      (ite ((_ is Double) d) (Double a!1) a!2))))) (let ((a!4 (ite (or ((_ is CelError) a!3))                 CelError                 (Bool (fp.eq (getDouble a!3)                              (fp #b0 #b10000000001 #x4000000000000)))))) (let ((a!5 (ite (or ((_ is CelUnknown) a!3))                 (CelUnknown (_==_ a!3                                   (Double (fp #b0 #b10000000001 #x4000000000000))))                 a!4)))   (not (= a!5 a!5))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
