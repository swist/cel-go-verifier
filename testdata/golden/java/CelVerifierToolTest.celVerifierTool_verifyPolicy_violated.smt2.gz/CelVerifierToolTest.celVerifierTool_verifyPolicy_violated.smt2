;; query 1 verifyImplication
(assert (not ((_ is CelError) port)))
(assert (not ((_ is CelUnknown) port)))
(assert (let ((a!1 (not (or (> (getInt port) 9223372036854775807)                     (< (getInt port) (- 9223372036854775808))))))   (or ((_ is CelError) port)       ((_ is CelUnknown) port)       (and ((_ is Int) port) a!1))))
(push)
(assert (let ((a!1 (Bool (> (getInt port) (getInt (Int 1024)))))) (let ((a!2 (ite (and ((_ is Int) port) ((_ is Int) (Int 1024)))                 a!1                 (ite (or ((_ is CelUnknown) port))                      (CelUnknown !generic_unknown)                      CelError)))) (let ((a!3 (ite (or ((_ is CelError) port) ((_ is CelError) (Int 1024)))                 CelError                 a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) port) ((_ is CelUnknown) (Int 1024)))                 (CelUnknown !generic_unknown)                 a!3)))   (and ((_ is Bool) (Bool true))        (getBool (Bool true))        (not (and ((_ is Bool) a!4) (getBool a!4)))))))))
(assert (let ((a!1 (ite (and ((_ is Int) port) ((_ is Int) (Int 1024))) false false)))   (not a!1)))
(check-sat) ; SATISFIABLE
