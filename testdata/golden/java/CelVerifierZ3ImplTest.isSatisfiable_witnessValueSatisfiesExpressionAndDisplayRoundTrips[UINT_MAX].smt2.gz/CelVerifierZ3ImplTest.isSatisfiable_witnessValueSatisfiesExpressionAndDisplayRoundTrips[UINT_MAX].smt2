;; query 1 isSatisfiable
(assert (not ((_ is CelError) u)))
(assert (not ((_ is CelUnknown) u)))
(assert (let ((a!1 (not (or (> (getUint u) 18446744073709551615) (< (getUint u) 0)))))   (or ((_ is CelError) u) ((_ is CelUnknown) u) (and ((_ is Uint) u) a!1))))
(push)
(assert (let ((a!1 (Bool (and (>= (getUint u) 18446744073709551615)                       (<= (getUint u) 18446744073709551615))))) (let ((a!2 (ite (or ((_ is CelUnknown) u))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) u)) CelError a!1))))   (and ((_ is Bool) a!2) (getBool a!2)))))
(assert (not false))
(check-sat) ; SATISFIABLE
