;; query 1 isAlwaysTrue
(assert (let ((a!1 (not (or (> (getInt !fn_g_zero) 9223372036854775807)                     (< (getInt !fn_g_zero) (- 9223372036854775808))))))   (or ((_ is CelError) !fn_g_zero)       ((_ is CelUnknown) !fn_g_zero)       (and ((_ is Int) !fn_g_zero) a!1))))
(assert (not ((_ is CelUnknown) !fn_g_zero)))
(assert (not ((_ is CelError) !fn_g_zero)))
(assert !approx!0)
(assert (not ((_ is CelError) g)))
(assert (not ((_ is CelUnknown) g)))
(assert (let ((a!1 (not (or (> (getInt g) 9223372036854775807)                     (< (getInt g) (- 9223372036854775808))))))   (or ((_ is CelError) g) ((_ is CelUnknown) g) (and ((_ is Int) g) a!1))))
(push)
(assert (let ((a!1 (ite (or ((_ is CelError) !fn_g_zero) ((_ is CelError) g))                 CelError                 (Bool (= (getInt !fn_g_zero) (getInt g)))))) (let ((a!2 ((_ is Bool)              (ite (or ((_ is CelUnknown) !fn_g_zero) ((_ is CelUnknown) g))                   (CelUnknown !generic_unknown)                   a!1)))       (a!3 (getBool (ite (or ((_ is CelUnknown) !fn_g_zero)                              ((_ is CelUnknown) g))                          (CelUnknown !generic_unknown)                          a!1))))   (not (and a!2 a!3)))))
(assert (let ((a!1 (and (or (and ((_ is CelError) !fn_g_zero) (not !approx!0))                     ((_ is CelError) g))                 (not (or ((_ is CelUnknown) !fn_g_zero) ((_ is CelUnknown) g)))))) (let ((a!2 (not (or (and ((_ is CelUnknown) !fn_g_zero) (not !approx!0))                     ((_ is CelUnknown) g)                     a!1                     (not !approx!0)))))   (not a!2))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (or ((_ is CelError) !fn_g_zero) ((_ is CelError) g))                 CelError                 (Bool (= (getInt !fn_g_zero) (getInt g)))))) (let ((a!2 ((_ is Bool)              (ite (or ((_ is CelUnknown) !fn_g_zero) ((_ is CelUnknown) g))                   (CelUnknown !generic_unknown)                   a!1)))       (a!3 (getBool (ite (or ((_ is CelUnknown) !fn_g_zero)                              ((_ is CelUnknown) g))                          (CelUnknown !generic_unknown)                          a!1))))   (not (and a!2 a!3)))))
(check-sat) ; SATISFIABLE
