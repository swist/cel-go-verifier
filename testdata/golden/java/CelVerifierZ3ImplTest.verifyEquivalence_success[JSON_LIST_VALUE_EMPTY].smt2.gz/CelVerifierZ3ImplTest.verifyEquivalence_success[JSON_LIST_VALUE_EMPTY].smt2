;; query 1 verifyEquivalence
(assert (= (as_seq !empty_list!0) (as seq.empty (Seq CelValue))))
(assert (= (!mkListRef (as_seq !empty_list!0)) !empty_list!0))
(assert (= (as_seq !listRef_!1) (as seq.empty (Seq CelValue))))
(assert (= (!mkListRef (as_seq !listRef_!1)) !listRef_!1))
(push)
(assert (not (= (List !empty_list!0) (List !listRef_!1))))
(assert (not (and ((_ is CelUnknown) (List !empty_list!0))           ((_ is CelUnknown) (List !listRef_!1)))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (not (= (List !empty_list!0) (List !listRef_!1))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
