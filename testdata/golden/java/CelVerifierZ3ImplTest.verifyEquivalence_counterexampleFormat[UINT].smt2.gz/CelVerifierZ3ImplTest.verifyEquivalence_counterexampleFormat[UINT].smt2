;; query 1 verifyEquivalence
(assert (not ((_ is CelError) u)))
(assert (not ((_ is CelUnknown) u)))
(assert (let ((a!1 (not (or (> (getUint u) 18446744073709551615) (< (getUint u) 0)))))   (or ((_ is CelError) u) ((_ is CelUnknown) u) (and ((_ is Uint) u) a!1))))
(push)
(assert (let ((a!1 (Bool (and (>= (getUint u) 443) (<= (getUint u) 443))))       (a!3 (Bool (and (>= (getUint u) 80) (<= (getUint u) 80))))) (let ((a!2 (ite (or ((_ is CelUnknown) u))                 (CelUnknown (_==_ u (Uint 443)))                 (ite (or ((_ is CelError) u)) CelError a!1)))       (a!4 (ite (or ((_ is CelUnknown) u))                 (CelUnknown (_==_ u (Uint 80)))                 (ite (or ((_ is CelError) u)) CelError a!3))))   (not (= a!2 a!4)))))
(assert (let ((a!1 (Bool (and (>= (getUint u) 443) (<= (getUint u) 443))))       (a!3 (Bool (and (>= (getUint u) 80) (<= (getUint u) 80))))) (let ((a!2 (ite (or ((_ is CelUnknown) u))                 (CelUnknown (_==_ u (Uint 443)))                 (ite (or ((_ is CelError) u)) CelError a!1)))       (a!4 (ite (or ((_ is CelUnknown) u))                 (CelUnknown (_==_ u (Uint 80)))                 (ite (or ((_ is CelError) u)) CelError a!3))))   (not (and ((_ is CelUnknown) a!2) ((_ is CelUnknown) a!4))))))
(check-sat) ; SATISFIABLE
