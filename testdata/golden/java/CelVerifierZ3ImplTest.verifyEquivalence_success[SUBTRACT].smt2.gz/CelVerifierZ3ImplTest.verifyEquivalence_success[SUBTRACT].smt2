;; query 1 verifyEquivalence
(assert (not ((_ is CelError) x)))
(assert (not ((_ is CelUnknown) x)))
(assert (let ((a!1 (not (or (> (getInt x) 9223372036854775807)                     (< (getInt x) (- 9223372036854775808))))))   (or ((_ is CelError) x) ((_ is CelUnknown) x) (and ((_ is Int) x) a!1))))
(assert (not ((_ is CelError) y)))
(assert (not ((_ is CelUnknown) y)))
(assert (let ((a!1 (not (or (> (getInt y) 9223372036854775807)                     (< (getInt y) (- 9223372036854775808))))))   (or ((_ is CelError) y) ((_ is CelUnknown) y) (and ((_ is Int) y) a!1))))
(push)
(assert (let ((a!1 (or (> (- (getInt x) (getInt y)) 9223372036854775807)                (< (- (getInt x) (getInt y)) (- 9223372036854775808))))) (let ((a!2 (ite a!1 CelError (Int (- (getInt x) (getInt y)))))) (let ((a!3 (ite (and ((_ is Int) x) ((_ is Int) y))                 a!2                 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) y))                      (CelUnknown (_-_ x y))                      CelError)))) (let ((a!4 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) y))                 (CelUnknown (_-_ x y))                 (ite (or ((_ is CelError) x) ((_ is CelError) y)) CelError a!3)))) (let ((a!5 (Bool (and (>= (getInt a!4) 5) (<= (getInt a!4) 5))))) (let ((a!6 (ite (or ((_ is CelUnknown) a!4))                 (CelUnknown (_==_ a!4 (Int 5)))                 (ite (or ((_ is CelError) a!4)) CelError a!5))))   (not (= a!6 a!6)))))))))
(assert (let ((a!1 (or (> (- (getInt x) (getInt y)) 9223372036854775807)                (< (- (getInt x) (getInt y)) (- 9223372036854775808))))       (a!5 (not (ite (and ((_ is Int) x) ((_ is Int) y)) false false)))) (let ((a!2 (ite a!1 CelError (Int (- (getInt x) (getInt y)))))) (let ((a!3 (ite (and ((_ is Int) x) ((_ is Int) y))                 a!2                 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) y))                      (CelUnknown (_-_ x y))                      CelError)))) (let ((a!4 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) y))                 (CelUnknown (_-_ x y))                 (ite (or ((_ is CelError) x) ((_ is CelError) y)) CelError a!3)))) (let ((a!6 (or (and ((_ is CelUnknown) a!4) a!5)                (and ((_ is CelError) a!4) a!5 (not ((_ is CelUnknown) a!4)))                a!5))       (a!7 (Bool (and (>= (getInt a!4) 5) (<= (getInt a!4) 5))))) (let ((a!8 (ite (or ((_ is CelUnknown) a!4))                 (CelUnknown (_==_ a!4 (Int 5)))                 (ite (or ((_ is CelError) a!4)) CelError a!7))))   (not (or (not a!6)            (not a!6)            (and ((_ is CelUnknown) a!8) ((_ is CelUnknown) a!8)))))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (or (> (- (getInt x) (getInt y)) 9223372036854775807)                (< (- (getInt x) (getInt y)) (- 9223372036854775808))))) (let ((a!2 (ite a!1 CelError (Int (- (getInt x) (getInt y)))))) (let ((a!3 (ite (and ((_ is Int) x) ((_ is Int) y))                 a!2                 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) y))                      (CelUnknown (_-_ x y))                      CelError)))) (let ((a!4 (ite (or ((_ is CelUnknown) x) ((_ is CelUnknown) y))                 (CelUnknown (_-_ x y))                 (ite (or ((_ is CelError) x) ((_ is CelError) y)) CelError a!3)))) (let ((a!5 (Bool (and (>= (getInt a!4) 5) (<= (getInt a!4) 5))))) (let ((a!6 (ite (or ((_ is CelUnknown) a!4))                 (CelUnknown (_==_ a!4 (Int 5)))                 (ite (or ((_ is CelError) a!4)) CelError a!5))))   (not (= a!6 a!6)))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
