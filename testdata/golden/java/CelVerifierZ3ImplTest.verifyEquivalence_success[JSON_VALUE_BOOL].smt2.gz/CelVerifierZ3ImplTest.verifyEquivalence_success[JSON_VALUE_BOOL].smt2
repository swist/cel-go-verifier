;; query 1 verifyEquivalence
(push)
(assert (not (= (Bool true) (Bool true))))
(assert (not (and ((_ is CelUnknown) (Bool true)) ((_ is CelUnknown) (Bool true)))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (not (= (Bool true) (Bool true))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
