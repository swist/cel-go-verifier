;; query 1 isAlwaysTrue
(assert (not ((_ is CelError) role)))
(assert (not ((_ is CelUnknown) role)))
(assert (or ((_ is CelError) role) ((_ is CelUnknown) role) ((_ is String) role)))
(push)
(assert (let ((a!1 (ite (and ((_ is String) role) ((_ is String) role))                 (Bool (str.prefixof (getString role) (getString role)))                 (ite (or ((_ is CelUnknown) role) ((_ is CelUnknown) role))                      (CelUnknown !generic_unknown)                      CelError)))) (let ((a!2 (ite (or ((_ is CelUnknown) role) ((_ is CelUnknown) role))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) role) ((_ is CelError) role))                      CelError                      a!1))))   (not (and ((_ is Bool) a!2) (getBool a!2))))))
(assert (not (ite (and ((_ is String) role) ((_ is String) role)) false false)))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (and ((_ is String) role) ((_ is String) role))                 (Bool (str.prefixof (getString role) (getString role)))                 (ite (or ((_ is CelUnknown) role) ((_ is CelUnknown) role))                      (CelUnknown !generic_unknown)                      CelError)))) (let ((a!2 (ite (or ((_ is CelUnknown) role) ((_ is CelUnknown) role))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) role) ((_ is CelError) role))                      CelError                      a!1))))   (not (and ((_ is Bool) a!2) (getBool a!2))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
