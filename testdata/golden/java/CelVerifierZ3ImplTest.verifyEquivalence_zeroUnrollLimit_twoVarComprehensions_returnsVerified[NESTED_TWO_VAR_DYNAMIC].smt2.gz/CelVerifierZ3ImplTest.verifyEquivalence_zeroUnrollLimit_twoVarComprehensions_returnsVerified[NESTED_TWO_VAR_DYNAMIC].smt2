;; query 1 verifyEquivalence
(assert (not ((_ is CelError) string_int_map)))
(assert (not ((_ is CelUnknown) string_int_map)))
(assert (let ((a!1 (<= (seq.len (map_keys (getMapRef string_int_map))) 0))       (a!3 (> (seq.len (map_keys (getMapRef string_int_map))) 0))) (let ((a!2 (=> a!1                (= (map_presence (getMapRef string_int_map))                   ((as const (Array CelValue Bool)) false)))))   (or ((_ is CelError) string_int_map)       ((_ is CelUnknown) string_int_map)       (and ((_ is Map) string_int_map)            a!2            (=> a!3 (!has_truncated_type_constraint string_int_map)))))))
(assert (not ((_ is CelError) int_list)))
(assert (not ((_ is CelUnknown) int_list)))
(assert (let ((a!1 (> (seq.len (as_seq (getListRef int_list))) 0)))   (or ((_ is CelError) int_list)       ((_ is CelUnknown) int_list)       (and ((_ is List) int_list)            (=> a!1 (!has_truncated_type_constraint int_list))))))
(assert (let ((a!1 (= (!mkListRef (as_seq (getListRef int_list))) (getListRef int_list))))   (=> ((_ is List) int_list) a!1)))
(assert (let ((a!1 (= (!mkMapRef (map_values (getMapRef string_int_map))                          (map_presence (getMapRef string_int_map)))               (getMapRef string_int_map))))   (=> ((_ is Map) string_int_map) a!1)))
(push)
(assert (let ((a!1 (> (seq.len (map_keys (getMapRef string_int_map))) 0))) (let ((a!2 (ite (or false (and ((_ is Map) string_int_map) a!1))                 (CelUnknown (!trunc_ec4be19080d29a31 string_int_map int_list))                 (Bool false)))) (let ((a!3 (ite ((_ is CelError) string_int_map)                 CelError                 (ite ((_ is CelUnknown) string_int_map)                      (CelUnknown (!trunc_ec4be19080d29a31                                    string_int_map                                    int_list))                      a!2))))   (not (= a!3 a!3))))))
(assert (let ((a!1 (> (seq.len (map_keys (getMapRef string_int_map))) 0))) (let ((a!2 (ite (or false (and ((_ is Map) string_int_map) a!1))                 (or false (and ((_ is Map) string_int_map) a!1) false)                 false))       (a!3 (ite (or false (and ((_ is Map) string_int_map) a!1))                 (CelUnknown (!trunc_ec4be19080d29a31 string_int_map int_list))                 (Bool false)))) (let ((a!4 (ite ((_ is CelError) string_int_map)                 CelError                 (ite ((_ is CelUnknown) string_int_map)                      (CelUnknown (!trunc_ec4be19080d29a31                                    string_int_map                                    int_list))                      a!3)))) (let ((a!5 (or (ite (or ((_ is CelError) string_int_map)                         ((_ is CelUnknown) string_int_map))                     false                     a!2)                (ite (or ((_ is CelError) string_int_map)                         ((_ is CelUnknown) string_int_map))                     false                     a!2)                (and ((_ is CelUnknown) a!4) ((_ is CelUnknown) a!4)))))   (not a!5))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (> (seq.len (map_keys (getMapRef string_int_map))) 0))) (let ((a!2 (ite (or false (and ((_ is Map) string_int_map) a!1))                 (CelUnknown (!trunc_ec4be19080d29a31 string_int_map int_list))                 (Bool false)))) (let ((a!3 (ite ((_ is CelError) string_int_map)                 CelError                 (ite ((_ is CelUnknown) string_int_map)                      (CelUnknown (!trunc_ec4be19080d29a31                                    string_int_map                                    int_list))                      a!2))))   (not (= a!3 a!3))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert (let ((a!1 (> (seq.len (map_keys (getMapRef string_int_map))) 0)))   (or (and ((_ is Map) string_int_map) a!1)       (and ((_ is Map) string_int_map) a!1))))
(check-sat) ; UNSATISFIABLE
(pop)
