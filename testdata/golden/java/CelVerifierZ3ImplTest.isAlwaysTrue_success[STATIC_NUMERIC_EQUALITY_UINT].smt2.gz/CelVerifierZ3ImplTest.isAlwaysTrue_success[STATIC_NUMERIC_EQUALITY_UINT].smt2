;; query 1 isAlwaysTrue
(assert (not ((_ is CelError) u)))
(assert (not ((_ is CelUnknown) u)))
(assert (let ((a!1 (not (or (> (getUint u) 18446744073709551615) (< (getUint u) 0)))))   (or ((_ is CelError) u) ((_ is CelUnknown) u) (and ((_ is Uint) u) a!1))))
(push)
(assert (let ((a!1 (ite (or ((_ is CelError) u) ((_ is CelError) u))                 CelError                 (Bool (= (getUint u) (getUint u)))))) (let ((a!2 ((_ is Bool)              (ite (or ((_ is CelUnknown) u) ((_ is CelUnknown) u))                   (CelUnknown !generic_unknown)                   a!1)))       (a!3 (getBool (ite (or ((_ is CelUnknown) u) ((_ is CelUnknown) u))                          (CelUnknown !generic_unknown)                          a!1))))   (not (and a!2 a!3)))))
(assert (not false))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (or ((_ is CelError) u) ((_ is CelError) u))                 CelError                 (Bool (= (getUint u) (getUint u)))))) (let ((a!2 ((_ is Bool)              (ite (or ((_ is CelUnknown) u) ((_ is CelUnknown) u))                   (CelUnknown !generic_unknown)                   a!1)))       (a!3 (getBool (ite (or ((_ is CelUnknown) u) ((_ is CelUnknown) u))                          (CelUnknown !generic_unknown)                          a!1))))   (not (and a!2 a!3)))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
