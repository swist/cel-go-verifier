;; query 1 verifyEquivalence
(assert (not ((_ is CelError) x)))
(assert (not ((_ is CelUnknown) x)))
(assert (let ((a!1 (not (or (> (getInt x) 9223372036854775807)                     (< (getInt x) (- 9223372036854775808))))))   (or ((_ is CelError) x) ((_ is CelUnknown) x) (and ((_ is Int) x) a!1))))
(push)
(assert (let ((a!1 (Bool (and (>= (getInt x) 0) (<= (getInt x) 0))))) (let ((a!2 (ite (or ((_ is CelUnknown) x))                 (CelUnknown (_==_ x (Int 0)))                 (ite (or ((_ is CelError) x)) CelError a!1))))   (not (= a!2 a!2)))))
(assert (let ((a!1 (Bool (and (>= (getInt x) 0) (<= (getInt x) 0))))) (let ((a!2 (ite (or ((_ is CelUnknown) x))                 (CelUnknown (_==_ x (Int 0)))                 (ite (or ((_ is CelError) x)) CelError a!1))))   (not (and ((_ is CelUnknown) a!2) ((_ is CelUnknown) a!2))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (Bool (and (>= (getInt x) 0) (<= (getInt x) 0))))) (let ((a!2 (ite (or ((_ is CelUnknown) x))                 (CelUnknown (_==_ x (Int 0)))                 (ite (or ((_ is CelError) x)) CelError a!1))))   (not (= a!2 a!2)))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
