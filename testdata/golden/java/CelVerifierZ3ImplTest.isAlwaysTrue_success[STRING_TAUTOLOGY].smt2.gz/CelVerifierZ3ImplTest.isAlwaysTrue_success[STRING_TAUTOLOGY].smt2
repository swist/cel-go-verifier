;; query 1 isAlwaysTrue
(assert (not ((_ is CelError) role)))
(assert (not ((_ is CelUnknown) role)))
(assert (or ((_ is CelError) role) ((_ is CelUnknown) role) ((_ is String) role)))
(assert (let ((a!1 (= (!mkListRef (as_seq (getListRef role))) (getListRef role))))   (=> ((_ is List) role) a!1)))
(assert (let ((a!1 (= (!mkMapRef (map_values (getMapRef role))                          (map_presence (getMapRef role)))               (getMapRef role))))   (=> ((_ is Map) role) a!1)))
(assert (let ((a!1 (= (!mkMsgRef (msg_type_name (getMessageRef role))                          (msg_values (getMessageRef role))                          (msg_presence (getMessageRef role)))               (getMessageRef role))))   (=> ((_ is Message) role) a!1)))
(push)
(assert (let ((a!1 (and (= (map_presence (getMapRef role))                    (map_presence (getMapRef role)))                 (= (map_values (getMapRef role)) (map_values (getMapRef role)))))       (a!2 (and (= (msg_type_name (getMessageRef role))                    (msg_type_name (getMessageRef role)))                 (= (msg_values (getMessageRef role))                    (msg_values (getMessageRef role)))                 (= (msg_presence (getMessageRef role))                    (msg_presence (getMessageRef role)))))) (let ((a!3 (ite (and ((_ is Message) role) ((_ is Message) role))                 a!2                 (ite (and ((_ is Double) role) ((_ is Double) role))                      (fp.eq (getDouble role) (getDouble role))                      (= role role))))) (let ((a!4 (ite (and ((_ is List) role) ((_ is List) role))                 (= (as_seq (getListRef role)) (as_seq (getListRef role)))                 (ite (and ((_ is Map) role) ((_ is Map) role)) a!1 a!3)))) (let ((a!5 (ite (or ((_ is CelUnknown) role) ((_ is CelUnknown) role))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) role) ((_ is CelError) role))                      CelError                      (Bool a!4)))))   (not (and ((_ is Bool) a!5) (getBool a!5))))))))
(assert (not false))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (and (= (map_presence (getMapRef role))                    (map_presence (getMapRef role)))                 (= (map_values (getMapRef role)) (map_values (getMapRef role)))))       (a!2 (and (= (msg_type_name (getMessageRef role))                    (msg_type_name (getMessageRef role)))                 (= (msg_values (getMessageRef role))                    (msg_values (getMessageRef role)))                 (= (msg_presence (getMessageRef role))                    (msg_presence (getMessageRef role)))))) (let ((a!3 (ite (and ((_ is Message) role) ((_ is Message) role))                 a!2                 (ite (and ((_ is Double) role) ((_ is Double) role))                      (fp.eq (getDouble role) (getDouble role))                      (= role role))))) (let ((a!4 (ite (and ((_ is List) role) ((_ is List) role))                 (= (as_seq (getListRef role)) (as_seq (getListRef role)))                 (ite (and ((_ is Map) role) ((_ is Map) role)) a!1 a!3)))) (let ((a!5 (ite (or ((_ is CelUnknown) role) ((_ is CelUnknown) role))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) role) ((_ is CelError) role))                      CelError                      (Bool a!4)))))   (not (and ((_ is Bool) a!5) (getBool a!5))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
