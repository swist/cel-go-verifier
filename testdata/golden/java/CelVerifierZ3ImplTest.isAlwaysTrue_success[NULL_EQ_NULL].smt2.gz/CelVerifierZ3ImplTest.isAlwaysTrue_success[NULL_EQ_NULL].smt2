;; query 1 isAlwaysTrue
(assert (let ((a!1 (= (!mkListRef (as_seq (getListRef CelNull))) (getListRef CelNull))))   (=> ((_ is List) CelNull) a!1)))
(assert (let ((a!1 (= (!mkMapRef (map_values (getMapRef CelNull))                          (map_presence (getMapRef CelNull)))               (getMapRef CelNull))))   (=> ((_ is Map) CelNull) a!1)))
(assert (let ((a!1 (= (!mkMsgRef (msg_type_name (getMessageRef CelNull))                          (msg_values (getMessageRef CelNull))                          (msg_presence (getMessageRef CelNull)))               (getMessageRef CelNull))))   (=> ((_ is Message) CelNull) a!1)))
(push)
(assert (let ((a!1 (and (= (map_presence (getMapRef CelNull))                    (map_presence (getMapRef CelNull)))                 (= (map_values (getMapRef CelNull))                    (map_values (getMapRef CelNull)))))       (a!2 (and (= (msg_type_name (getMessageRef CelNull))                    (msg_type_name (getMessageRef CelNull)))                 (= (msg_values (getMessageRef CelNull))                    (msg_values (getMessageRef CelNull)))                 (= (msg_presence (getMessageRef CelNull))                    (msg_presence (getMessageRef CelNull)))))) (let ((a!3 (ite (and ((_ is Message) CelNull) ((_ is Message) CelNull))                 a!2                 (ite (and ((_ is Double) CelNull) ((_ is Double) CelNull))                      (fp.eq (getDouble CelNull) (getDouble CelNull))                      (= CelNull CelNull))))) (let ((a!4 (ite (and ((_ is List) CelNull) ((_ is List) CelNull))                 (= (as_seq (getListRef CelNull)) (as_seq (getListRef CelNull)))                 (ite (and ((_ is Map) CelNull) ((_ is Map) CelNull)) a!1 a!3))))   (not (and ((_ is Bool) (Bool a!4)) (getBool (Bool a!4))))))))
(assert (not false))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (and (= (map_presence (getMapRef CelNull))                    (map_presence (getMapRef CelNull)))                 (= (map_values (getMapRef CelNull))                    (map_values (getMapRef CelNull)))))       (a!2 (and (= (msg_type_name (getMessageRef CelNull))                    (msg_type_name (getMessageRef CelNull)))                 (= (msg_values (getMessageRef CelNull))                    (msg_values (getMessageRef CelNull)))                 (= (msg_presence (getMessageRef CelNull))                    (msg_presence (getMessageRef CelNull)))))) (let ((a!3 (ite (and ((_ is Message) CelNull) ((_ is Message) CelNull))                 a!2                 (ite (and ((_ is Double) CelNull) ((_ is Double) CelNull))                      (fp.eq (getDouble CelNull) (getDouble CelNull))                      (= CelNull CelNull))))) (let ((a!4 (ite (and ((_ is List) CelNull) ((_ is List) CelNull))                 (= (as_seq (getListRef CelNull)) (as_seq (getListRef CelNull)))                 (ite (and ((_ is Map) CelNull) ((_ is Map) CelNull)) a!1 a!3))))   (not (and ((_ is Bool) (Bool a!4)) (getBool (Bool a!4))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
