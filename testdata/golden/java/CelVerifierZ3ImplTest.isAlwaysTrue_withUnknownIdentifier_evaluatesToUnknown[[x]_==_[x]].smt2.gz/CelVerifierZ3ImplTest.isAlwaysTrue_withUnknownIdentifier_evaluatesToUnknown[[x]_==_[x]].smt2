;; query 1 isAlwaysTrue
(assert (not ((_ is CelError) x)))
(assert (let ((a!1 (not (or (> (getInt x) 9223372036854775807)                     (< (getInt x) (- 9223372036854775808))))))   (or ((_ is CelUnknown) x)       ((_ is CelError) x)       ((_ is CelUnknown) x)       (and ((_ is Int) x) a!1))))
(assert (= (as_seq !listRef_!0) (seq.++ (as seq.empty (Seq CelValue)) (seq.unit x))))
(assert (=> (!has_truncated_type_constraint x)     (or ((_ is CelError) (List !listRef_!0))         ((_ is CelUnknown) (List !listRef_!0))         (!has_truncated_type_constraint (List !listRef_!0)))))
(assert (= (!mkListRef (as_seq !listRef_!0)) !listRef_!0))
(assert (let ((a!1 (ite (or ((_ is CelUnknown) x))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) x)) CelError (List !listRef_!0))))) (let ((a!2 (= (!mkListRef (as_seq (getListRef a!1))) (getListRef a!1))))   (=> ((_ is List) a!1) a!2))))
(push)
(assert (let ((a!1 (ite (or ((_ is CelUnknown) x))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) x)) CelError (List !listRef_!0))))) (let ((a!2 (= (seq.len (as_seq (getListRef a!1)))               (seq.len (as_seq (getListRef a!1)))))       (a!3 ((_ is CelUnknown) (seq.nth (as_seq (getListRef a!1)) 0)))       (a!4 ((_ is CelError) (seq.nth (as_seq (getListRef a!1)) 0)))       (a!5 (getInt (seq.nth (as_seq (getListRef a!1)) 0)))) (let ((a!6 (ite (or a!3 a!3)                 (CelUnknown !generic_unknown)                 (ite (or a!4 a!4) CelError (Bool (= a!5 a!5)))))) (let ((a!7 (ite (or ((_ is CelError) a!1) ((_ is CelError) a!1))                 CelError                 (Bool (and a!2 ((_ is Bool) a!6) (getBool a!6)))))) (let ((a!8 ((_ is Bool)              (ite (or ((_ is CelUnknown) a!1) ((_ is CelUnknown) a!1))                   (CelUnknown !generic_unknown)                   a!7)))       (a!9 (getBool (ite (or ((_ is CelUnknown) a!1) ((_ is CelUnknown) a!1))                          (CelUnknown !generic_unknown)                          a!7))))   (not (and a!8 a!9))))))))
(assert (not false))
(check-sat) ; SATISFIABLE
