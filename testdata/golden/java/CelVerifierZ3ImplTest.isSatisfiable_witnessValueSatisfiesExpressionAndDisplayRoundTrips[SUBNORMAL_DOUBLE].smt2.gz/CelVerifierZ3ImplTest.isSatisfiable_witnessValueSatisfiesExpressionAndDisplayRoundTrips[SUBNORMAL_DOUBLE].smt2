;; query 1 isSatisfiable
(assert (not ((_ is CelError) d)))
(assert (not ((_ is CelUnknown) d)))
(assert (let ((a!1 (Double (ite (fp.isNaN (getDouble d)) (_ NaN 11 53) (getDouble d))))) (let ((a!2 (and ((_ is Double) d) (=> (fp.isNaN (getDouble d)) (= d a!1)))))   (or ((_ is CelError) d) ((_ is CelUnknown) d) a!2))))
(push)
(assert (let ((a!1 (ite (or ((_ is CelError) d))                 CelError                 (Bool (fp.eq (getDouble d)                              (fp #b0 #b00000000000 #x0000000000001)))))) (let ((a!2 ((_ is Bool)              (ite (or ((_ is CelUnknown) d)) (CelUnknown !generic_unknown) a!1)))       (a!3 (getBool (ite (or ((_ is CelUnknown) d))                          (CelUnknown !generic_unknown)                          a!1))))   (and a!2 a!3))))
(assert (not false))
(check-sat) ; SATISFIABLE
