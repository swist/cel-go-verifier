;; query 1 verifyEquivalence
(push)
(assert (let ((a!1 (ite (not ((_ is Bytes) (Bytes "abc"))) CelError (Bytes "abc"))))   (not (= a!1 (Bytes "abc")))))
(assert (let ((a!1 (ite (not ((_ is Bytes) (Bytes "abc"))) CelError (Bytes "abc"))))   (not (and ((_ is CelUnknown) a!1) ((_ is CelUnknown) (Bytes "abc"))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (not ((_ is Bytes) (Bytes "abc"))) CelError (Bytes "abc"))))   (not (= a!1 (Bytes "abc")))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
