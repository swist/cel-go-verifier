;; query 1 verifyEquivalence
(assert (not ((_ is CelError) dyn_list)))
(assert (not ((_ is CelUnknown) dyn_list)))
(assert (or ((_ is CelError) dyn_list)     ((_ is CelUnknown) dyn_list)     ((_ is List) dyn_list)))
(assert (let ((a!1 (= (!mkListRef (as_seq (getListRef dyn_list))) (getListRef dyn_list))))   (=> ((_ is List) dyn_list) a!1)))
(push)
(assert (let ((a!1 (> (seq.len (as_seq (getListRef dyn_list))) 0))) (let ((a!2 (ite (or ((_ is CelUnknown) dyn_list)                     (and ((_ is List) dyn_list) a!1))                 (CelUnknown (!trunc_a422771541976a1c dyn_list))                 (Bool true)))       (a!3 (ite (or ((_ is CelUnknown) dyn_list)                     (and ((_ is List) dyn_list) a!1))                 (CelUnknown (!trunc_4ff5c322c9fd95bc dyn_list))                 (Bool true))))   (not (= (ite ((_ is CelError) dyn_list) CelError a!2)           (ite ((_ is CelError) dyn_list) CelError a!3))))))
(assert (let ((a!1 (> (seq.len (as_seq (getListRef dyn_list))) 0))) (let ((a!2 (ite (or ((_ is CelError) dyn_list) ((_ is CelUnknown) dyn_list))                 false                 (and ((_ is List) dyn_list) a!1)))       (a!3 (ite (or ((_ is CelUnknown) dyn_list)                     (and ((_ is List) dyn_list) a!1))                 (CelUnknown (!trunc_a422771541976a1c dyn_list))                 (Bool true)))       (a!4 (ite (or ((_ is CelUnknown) dyn_list)                     (and ((_ is List) dyn_list) a!1))                 (CelUnknown (!trunc_4ff5c322c9fd95bc dyn_list))                 (Bool true)))) (let ((a!5 (and ((_ is CelUnknown)                   (ite ((_ is CelError) dyn_list) CelError a!3))                 ((_ is CelUnknown)                   (ite ((_ is CelError) dyn_list) CelError a!4)))))   (not (or a!2 a!2 a!5))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (> (seq.len (as_seq (getListRef dyn_list))) 0))) (let ((a!2 (ite (or ((_ is CelUnknown) dyn_list)                     (and ((_ is List) dyn_list) a!1))                 (CelUnknown (!trunc_a422771541976a1c dyn_list))                 (Bool true)))       (a!3 (ite (or ((_ is CelUnknown) dyn_list)                     (and ((_ is List) dyn_list) a!1))                 (CelUnknown (!trunc_4ff5c322c9fd95bc dyn_list))                 (Bool true))))   (not (= (ite ((_ is CelError) dyn_list) CelError a!2)           (ite ((_ is CelError) dyn_list) CelError a!3))))))
(check-sat) ; SATISFIABLE
