;; query 1 isAlwaysTrue
(push)
(assert (let ((a!1 (or ((_ is CelUnknown) (ite true (Int 42) CelError))))       (a!2 (or ((_ is CelError) (ite true (Int 42) CelError))))       (a!3 (>= (getInt (ite true (Int 42) CelError)) 42))       (a!4 (<= (getInt (ite true (Int 42) CelError)) 42))) (let ((a!5 (ite a!1                 (CelUnknown !generic_unknown)                 (ite a!2 CelError (Bool (and a!3 a!4))))))   (not (and ((_ is Bool) a!5) (getBool a!5))))))
(assert (let ((a!1 (and ((_ is CelUnknown) (ite true (Int 42) CelError))                 (not (ite true false false))))       (a!2 (not ((_ is CelUnknown) (ite true (Int 42) CelError))))) (let ((a!3 (and ((_ is CelError) (ite true (Int 42) CelError))                 (not (ite true false false))                 a!2))) (let ((a!4 (not (or a!1 a!3 (not (ite true false false))))))   (not a!4)))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (or ((_ is CelUnknown) (ite true (Int 42) CelError))))       (a!2 (or ((_ is CelError) (ite true (Int 42) CelError))))       (a!3 (>= (getInt (ite true (Int 42) CelError)) 42))       (a!4 (<= (getInt (ite true (Int 42) CelError)) 42))) (let ((a!5 (ite a!1                 (CelUnknown !generic_unknown)                 (ite a!2 CelError (Bool (and a!3 a!4))))))   (not (and ((_ is Bool) a!5) (getBool a!5))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
