;; query 1 verifyEquivalence
(push)
(assert (not (= CelNull CelNull)))
(assert (not (and ((_ is CelUnknown) CelNull) ((_ is CelUnknown) CelNull))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (not (= CelNull CelNull)))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
