;; query 1 verifyEquivalence
(push)
(assert (let ((a!1 (ite (not ((_ is String) (String "hello")))                 CelError                 (String "hello"))))   (not (= a!1 (String "hello")))))
(assert (let ((a!1 (ite (not ((_ is String) (String "hello")))                 CelError                 (String "hello"))))   (not (and ((_ is CelUnknown) a!1) ((_ is CelUnknown) (String "hello"))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (not ((_ is String) (String "hello")))                 CelError                 (String "hello"))))   (not (= a!1 (String "hello")))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
