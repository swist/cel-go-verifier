;; query 1 isAlwaysTrue
(push)
(assert (let ((a!1 (Bool (fp.lt (fp #b0 #b01111111111 #x0000000000000)                         (getDouble (Double (fp #b0 #b10000000000 #x0000000000000))))))) (let ((a!2 (ite (and ((_ is Int) (Int 1))                      ((_ is Double)                        (Double (fp #b0 #b10000000000 #x0000000000000))))                 a!1                 CelError))) (let ((a!3 (ite (or ((_ is CelError) (Int 1))                     ((_ is CelError)                       (Double (fp #b0 #b10000000000 #x0000000000000))))                 CelError                 a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) (Int 1))                     ((_ is CelUnknown)                       (Double (fp #b0 #b10000000000 #x0000000000000))))                 (CelUnknown !generic_unknown)                 a!3)))   (not (and ((_ is Bool) a!4) (getBool a!4))))))))
(assert (let ((a!1 (ite (and ((_ is Int) (Int 1))                      ((_ is Double)                        (Double (fp #b0 #b10000000000 #x0000000000000))))                 false                 false)))   (not a!1)))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (Bool (fp.lt (fp #b0 #b01111111111 #x0000000000000)                         (getDouble (Double (fp #b0 #b10000000000 #x0000000000000))))))) (let ((a!2 (ite (and ((_ is Int) (Int 1))                      ((_ is Double)                        (Double (fp #b0 #b10000000000 #x0000000000000))))                 a!1                 CelError))) (let ((a!3 (ite (or ((_ is CelError) (Int 1))                     ((_ is CelError)                       (Double (fp #b0 #b10000000000 #x0000000000000))))                 CelError                 a!2))) (let ((a!4 (ite (or ((_ is CelUnknown) (Int 1))                     ((_ is CelUnknown)                       (Double (fp #b0 #b10000000000 #x0000000000000))))                 (CelUnknown !generic_unknown)                 a!3)))   (not (and ((_ is Bool) a!4) (getBool a!4))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
