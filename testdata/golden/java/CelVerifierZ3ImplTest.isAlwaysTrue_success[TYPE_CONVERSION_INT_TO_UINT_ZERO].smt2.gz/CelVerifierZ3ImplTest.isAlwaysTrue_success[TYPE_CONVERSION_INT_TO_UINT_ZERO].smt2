;; query 1 isAlwaysTrue
(push)
(assert (let ((a!1 (ite (< (getInt (Int 0)) 0) CelError (Uint (getInt (Int 0)))))) (let ((a!2 (ite (or ((_ is CelError) (Int 0)))                 CelError                 (ite ((_ is Int) (Int 0)) a!1 CelError)))) (let ((a!3 (ite (or ((_ is CelUnknown) (Int 0)))                 (CelUnknown !generic_unknown)                 a!2))) (let ((a!4 (Bool (and (>= (getUint a!3) 0) (<= (getUint a!3) 0))))) (let ((a!5 (ite (or ((_ is CelUnknown) a!3))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) a!3)) CelError a!4))))   (not (and ((_ is Bool) a!5) (getBool a!5)))))))))
(assert (let ((a!1 (ite (< (getInt (Int 0)) 0) CelError (Uint (getInt (Int 0)))))       (a!4 (not (ite ((_ is Int) (Int 0)) false false)))) (let ((a!2 (ite (or ((_ is CelError) (Int 0)))                 CelError                 (ite ((_ is Int) (Int 0)) a!1 CelError)))) (let ((a!3 (ite (or ((_ is CelUnknown) (Int 0)))                 (CelUnknown !generic_unknown)                 a!2))) (let ((a!5 (or (and ((_ is CelUnknown) a!3) a!4)                (and ((_ is CelError) a!3) a!4 (not ((_ is CelUnknown) a!3)))                a!4)))   (not (not a!5)))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite (< (getInt (Int 0)) 0) CelError (Uint (getInt (Int 0)))))) (let ((a!2 (ite (or ((_ is CelError) (Int 0)))                 CelError                 (ite ((_ is Int) (Int 0)) a!1 CelError)))) (let ((a!3 (ite (or ((_ is CelUnknown) (Int 0)))                 (CelUnknown !generic_unknown)                 a!2))) (let ((a!4 (Bool (and (>= (getUint a!3) 0) (<= (getUint a!3) 0))))) (let ((a!5 (ite (or ((_ is CelUnknown) a!3))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) a!3)) CelError a!4))))   (not (and ((_ is Bool) a!5) (getBool a!5)))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
