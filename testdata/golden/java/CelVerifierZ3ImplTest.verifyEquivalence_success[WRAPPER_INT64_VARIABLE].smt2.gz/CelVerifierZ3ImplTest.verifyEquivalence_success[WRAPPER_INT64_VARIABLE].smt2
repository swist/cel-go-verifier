;; query 1 verifyEquivalence
(assert (not ((_ is CelError) x)))
(assert (not ((_ is CelUnknown) x)))
(assert (let ((a!1 (not (or (> (getInt x) 9223372036854775807)                     (< (getInt x) (- 9223372036854775808))))))   (or ((_ is CelError) x) ((_ is CelUnknown) x) (and ((_ is Int) x) a!1))))
(push)
(assert (let ((a!1 (not (or (> (getInt x) 9223372036854775807)                     (< (getInt x) (- 9223372036854775808)))))) (let ((a!2 (ite (not (and ((_ is Int) x) a!1)) CelError x))) (let ((a!3 (ite (or ((_ is CelUnknown) x))                 (CelUnknown (|struct_google.protobuf.Int64Value_value:false| x))                 (ite (or ((_ is CelError) x)) CelError a!2))))   (not (= a!3 x))))))
(assert (let ((a!1 (not (or (> (getInt x) 9223372036854775807)                     (< (getInt x) (- 9223372036854775808)))))) (let ((a!2 (ite (not (and ((_ is Int) x) a!1)) CelError x))) (let ((a!3 (ite (or ((_ is CelUnknown) x))                 (CelUnknown (|struct_google.protobuf.Int64Value_value:false| x))                 (ite (or ((_ is CelError) x)) CelError a!2))))   (not (and ((_ is CelUnknown) a!3) ((_ is CelUnknown) x)))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (not (or (> (getInt x) 9223372036854775807)                     (< (getInt x) (- 9223372036854775808)))))) (let ((a!2 (ite (not (and ((_ is Int) x) a!1)) CelError x))) (let ((a!3 (ite (or ((_ is CelUnknown) x))                 (CelUnknown (|struct_google.protobuf.Int64Value_value:false| x))                 (ite (or ((_ is CelError) x)) CelError a!2))))   (not (= a!3 x))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
