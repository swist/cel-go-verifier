;; query 1 isAlwaysTrue
(assert (not ((_ is CelError) role)))
(assert (not ((_ is CelUnknown) role)))
(assert (or ((_ is CelError) role) ((_ is CelUnknown) role) ((_ is String) role)))
(assert (<= (str.len (getString role)) 2147483647))
(push)
(assert (let ((a!1 (ite ((_ is String) role)                 (Int (str.len (getString role)))                 (ite (or ((_ is CelUnknown) role))                      (CelUnknown !generic_unknown)                      CelError)))) (let ((a!2 (ite (or ((_ is CelUnknown) role))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) role)) CelError a!1)))) (let ((a!3 (Bool (>= (getInt a!2) (getInt (Int 0)))))) (let ((a!4 (ite (and ((_ is Int) a!2) ((_ is Int) (Int 0)))                 a!3                 (ite (or ((_ is CelUnknown) a!2))                      (CelUnknown !generic_unknown)                      CelError)))) (let ((a!5 (ite (or ((_ is CelError) a!2) ((_ is CelError) (Int 0)))                 CelError                 a!4))) (let ((a!6 (ite (or ((_ is CelUnknown) a!2) ((_ is CelUnknown) (Int 0)))                 (CelUnknown !generic_unknown)                 a!5)))   (not (and ((_ is Bool) a!6) (getBool a!6))))))))))
(assert (let ((a!1 (ite ((_ is String) role)                 (Int (str.len (getString role)))                 (ite (or ((_ is CelUnknown) role))                      (CelUnknown !generic_unknown)                      CelError)))       (a!3 (and (or (ite ((_ is String) role) false false) false)                 (ite ((_ is String) role) false false)))) (let ((a!2 (ite (or ((_ is CelUnknown) role))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) role)) CelError a!1)))) (let ((a!4 (and ((_ is CelUnknown) a!2)                 (not (ite ((_ is String) role) false false))))       (a!5 (and ((_ is CelError) a!2)                 (not (ite ((_ is String) role) false false))                 (not ((_ is CelUnknown) a!2))))) (let ((a!6 (or a!4 a!5 (not (ite ((_ is String) role) false false))))) (let ((a!7 (ite (and ((_ is Int) a!2) ((_ is Int) (Int 0))) a!3 (not a!6))))   (not a!7)))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert (let ((a!1 (ite ((_ is String) role)                 (Int (str.len (getString role)))                 (ite (or ((_ is CelUnknown) role))                      (CelUnknown !generic_unknown)                      CelError)))) (let ((a!2 (ite (or ((_ is CelUnknown) role))                 (CelUnknown !generic_unknown)                 (ite (or ((_ is CelError) role)) CelError a!1)))) (let ((a!3 (Bool (>= (getInt a!2) (getInt (Int 0)))))) (let ((a!4 (ite (and ((_ is Int) a!2) ((_ is Int) (Int 0)))                 a!3                 (ite (or ((_ is CelUnknown) a!2))                      (CelUnknown !generic_unknown)                      CelError)))) (let ((a!5 (ite (or ((_ is CelError) a!2) ((_ is CelError) (Int 0)))                 CelError                 a!4))) (let ((a!6 (ite (or ((_ is CelUnknown) a!2) ((_ is CelUnknown) (Int 0)))                 (CelUnknown !generic_unknown)                 a!5)))   (not (and ((_ is Bool) a!6) (getBool a!6))))))))))
(check-sat) ; UNSATISFIABLE
(pop)
(push)
(assert false)
(assert false)
(check-sat) ; UNSATISFIABLE
(pop)
